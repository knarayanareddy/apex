/**
 * Ring 5 — Self-Contained Mission-Control Operator Cockpit UI (`src/ring5/mission-control-ui.ts`).
 *
 * PREVIEW & CONFINEMENT GUARANTEES:
 *  - Zero external CDN scripts, stylesheets, or fonts (renders instantaneously offline or in sandboxed previews).
 *  - Strictly relative API & SSE URLs (`./api/...` and `new EventSource("./api/events")`) — zero `localhost`
 *    or `127.0.0.1` literals so reverse-proxied browser previews (`https://{port}-{sandboxId}.e2b.app`)
 *    and local desktop browsers work identically.
 */

let _validatedInlineScript = false;

export function renderMissionControlHtml(): string {
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Pi-Apex Mission Control — Rings 0–8 (v3.8.0)</title>
  <style>
    :root {
      --bg: #0b0f17;
      --panel: #121826;
      --panel-alt: #182033;
      --border: #25314d;
      --text: #e6edf7;
      --muted: #8b9bb4;
      --accent: #38bdf8;
      --accent-dim: rgba(56, 189, 248, 0.14);
      --ok: #22c55e;
      --ok-dim: rgba(34, 197, 94, 0.14);
      --warn: #f59e0b;
      --warn-dim: rgba(245, 158, 11, 0.15);
      --danger: #ef4444;
      --danger-dim: rgba(239, 68, 68, 0.16);
      --mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      --sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      background: var(--bg);
      color: var(--text);
      font-family: var(--sans);
      font-size: 13.5px;
      line-height: 1.45;
    }
    header {
      background: linear-gradient(180deg, #131b2e 0%, #0e1422 100%);
      border-bottom: 1px solid var(--border);
      padding: 14px 20px;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
    }
    .brand {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .brand-dot {
      width: 11px;
      height: 11px;
      border-radius: 50%;
      background: var(--ok);
      box-shadow: 0 0 10px var(--ok);
    }
    .brand h1 {
      margin: 0;
      font-size: 16px;
      font-weight: 650;
      letter-spacing: -0.01em;
    }
    .brand span {
      color: var(--muted);
      font-size: 12px;
      font-family: var(--mono);
    }
    .badges {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      align-items: center;
    }
    .badge {
      font-family: var(--mono);
      font-size: 11.5px;
      padding: 4px 9px;
      border-radius: 999px;
      border: 1px solid var(--border);
      background: var(--panel);
      color: var(--text);
    }
    .badge.ok { border-color: rgba(34,197,94,0.45); background: var(--ok-dim); color: #86efac; }
    .badge.warn { border-color: rgba(245,158,11,0.45); background: var(--warn-dim); color: #fcd34d; }
    .badge.danger { border-color: rgba(239,68,68,0.45); background: var(--danger-dim); color: #fca5a5; }
    .badge.accent { border-color: rgba(56,189,248,0.45); background: var(--accent-dim); color: #7dd3fc; }
    .toolbar {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }
    button {
      background: var(--panel-alt);
      color: var(--text);
      border: 1px solid var(--border);
      border-radius: 6px;
      padding: 6px 11px;
      font-size: 12.5px;
      font-weight: 550;
      cursor: pointer;
      transition: border-color 0.15s, background 0.15s;
    }
    button:hover { border-color: var(--accent); background: #1e2942; }
    button.primary { background: #0284c7; border-color: #38bdf8; color: #fff; }
    button.primary:hover { background: #0369a1; }
    button.success { background: #15803d; border-color: #22c55e; color: #fff; }
    button.danger { background: #b91c1c; border-color: #ef4444; color: #fff; }
    nav.tabs {
      display: flex;
      gap: 4px;
      padding: 10px 20px 0;
      border-bottom: 1px solid var(--border);
      background: #0e1422;
      overflow-x: auto;
    }
    nav.tabs button {
      border-bottom-left-radius: 0;
      border-bottom-right-radius: 0;
      border-bottom: none;
      background: transparent;
      color: var(--muted);
      padding: 8px 14px;
    }
    nav.tabs button.active {
      background: var(--bg);
      color: var(--accent);
      border-color: var(--border);
      font-weight: 650;
    }
    main {
      padding: 18px 20px 32px;
      max-width: 1440px;
      margin: 0 auto;
    }
    .toast {
      margin-bottom: 14px;
      padding: 10px 14px;
      border-radius: 7px;
      border: 1px solid var(--border);
      background: var(--panel);
      font-family: var(--mono);
      font-size: 12px;
      display: none;
      white-space: pre-wrap;
    }
    .toast.visible { display: block; }
    .toast.error { border-color: var(--danger); background: var(--danger-dim); color: #fecaca; }
    .toast.ok { border-color: var(--ok); background: var(--ok-dim); color: #bbf7d0; }
    .grid-2 {
      display: grid;
      grid-template-columns: 1fr 1.35fr;
      gap: 16px;
    }
    .grid-equal {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }
    @media (max-width: 960px) {
      .grid-2, .grid-equal { grid-template-columns: 1fr; }
    }
    .card {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 9px;
      padding: 14px 16px;
    }
    .card h2 {
      margin: 0 0 10px;
      font-size: 14px;
      font-weight: 650;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }
    .muted { color: var(--muted); font-size: 12px; }
    .mono { font-family: var(--mono); }
    .list-item {
      padding: 10px 12px;
      border: 1px solid var(--border);
      border-radius: 7px;
      background: var(--panel-alt);
      margin-bottom: 8px;
      cursor: pointer;
    }
    .list-item:hover, .list-item.selected {
      border-color: var(--accent);
    }
    .code-lines {
      background: #090d15;
      border: 1px solid var(--border);
      border-radius: 7px;
      padding: 10px;
      font-family: var(--mono);
      font-size: 12px;
      max-height: 300px;
      overflow: auto;
    }
    .code-line {
      display: flex;
      gap: 10px;
      padding: 2px 6px;
      border-radius: 4px;
    }
    .code-line:hover { background: rgba(56, 189, 248, 0.1); }
    .line-num {
      color: var(--muted);
      min-width: 28px;
      text-align: right;
      user-select: none;
    }
    input, textarea, select {
      width: 100%;
      background: #090d15;
      color: var(--text);
      border: 1px solid var(--border);
      border-radius: 6px;
      padding: 7px 9px;
      font-family: var(--sans);
      font-size: 12.5px;
      margin-top: 4px;
      margin-bottom: 8px;
    }
    textarea { font-family: var(--mono); min-height: 76px; resize: vertical; }
    .row { display: flex; gap: 8px; align-items: center; }
    pre.surface-box {
      background: #090d15;
      border: 1px solid var(--border);
      border-radius: 7px;
      padding: 11px;
      font-family: var(--mono);
      font-size: 12px;
      white-space: pre-wrap;
      max-height: 290px;
      overflow: auto;
      margin: 6px 0 0;
    }
    .tab-pane { display: none; }
    .tab-pane.active { display: block; }
    .meter {
      height: 7px;
      background: #090d15;
      border-radius: 999px;
      overflow: hidden;
      border: 1px solid var(--border);
      margin-top: 6px;
    }
    .meter > div {
      height: 100%;
      background: linear-gradient(90deg, #22c55e, #38bdf8);
    }
  </style>
</head>
<body>
  <header>
    <div class="brand">
      <div class="brand-dot" id="sseDot" title="SSE Live Connection"></div>
      <div>
        <h1>Pi-Apex Mission Control</h1>
        <span id="workspaceLabel">loading workspace...</span>
      </div>
    </div>
    <div class="badges">
      <span class="badge ok" id="schemaBadge">Schema: 1073 o200k</span>
      <span class="badge accent" id="prefixBadge">Prefix: -- / 2100</span>
      <span class="badge ok" id="guardrailsBadge">GUARDRAILS Pin: Verified</span>
      <span class="badge accent" id="modelCacheBadge">Model: -- | Cache: 0%</span>
      <span class="badge" id="planModeBadge">Mode: --</span>
    </div>
    <div class="toolbar">
      <button id="btnTogglePlan">Toggle Plan Mode</button>
      <button id="btnDoctor">/doctor Audit</button>
      <button class="primary" id="btnNewSession">/new Session Reload</button>
    </div>
  </header>

  <nav class="tabs">
    <button class="active" data-tab="tab-chat">1. Live Chat &amp; Git Diffs</button>
    <button data-tab="tab-artifacts">2. Trust Artifacts &amp; Inline Steer</button>
    <button data-tab="tab-quarantine">3. Skill Quarantine Gate (v10)</button>
    <button data-tab="tab-rewind">4. /tree Git Rewind &amp; WAL</button>
    <button data-tab="tab-evolution">5. Dreaming, Harness² &amp; Slash Console</button>
    <button data-tab="tab-models-mcp">6. Models, Ollama, Sessions &amp; MCP</button>
    <button data-tab="tab-ring7">7. PR Pipeline, Handoff, Browser CDP &amp; Workspaces</button>
    <button data-tab="tab-ring8">8. GitHub Fence, VS Code RPC &amp; SWE Bench</button>
    <button data-tab="tab-ring9">9. Gateway, Swarm, Plugins &amp; Ledger</button>
  </nav>

  <main>
    <div id="toast" class="toast"></div>

    <!-- TAB 0 (v2): LIVE STREAMING CHAT & UNIFIED GIT DIFF VIEWER -->
    <section id="tab-chat" class="tab-pane active">
      <div class="grid-equal">
        <div class="card">
          <h2>
            <span>Multi-Turn Streaming Agent Transcript</span>
            <span class="muted" id="chatStreamingBadge">idle</span>
          </h2>
          <div id="chatTranscriptBox" style="max-height:360px;overflow-y:auto;display:flex;flex-direction:column;gap:8px;margin-bottom:10px;"></div>
          <pre class="surface-box" id="liveStreamBox" style="display:none;min-height:48px;border-color:#38bdf8;"></pre>
          <textarea id="chatPromptInput" rows="3" placeholder="Ask Pi-Apex to inspect code, propose a Plan Trust Artifact, invoke deferred tools, or type a /slash command..."></textarea>
          <div class="row" style="margin-top:8px;">
            <button class="primary" id="btnSendPrompt">Send Prompt</button>
            <button id="btnSteerPrompt">Steer In-Flight</button>
            <button class="danger" id="btnAbortTurn">Abort Turn</button>
          </div>
        </div>

        <div class="card">
          <h2>
            <span>Workspace Git Diff Viewer (<code>git diff HEAD</code>)</span>
            <div class="row">
              <button id="btnRefreshDiff">Refresh Diff</button>
              <button class="primary" id="btnRunBugBot">BugBot Diff Review</button>
            </div>
          </h2>
          <div class="muted" id="diffStatusSummary" style="margin-bottom:8px;">Clean working tree.</div>
          <pre class="surface-box" id="diffViewerBox" style="max-height:410px;overflow:auto;">(no uncommitted diff against HEAD)</pre>
        </div>
      </div>
    </section>

    <!-- TAB 1: TRUST ARTIFACTS & INLINE STEER -->
    <section id="tab-artifacts" class="tab-pane">
      <div class="grid-2">
        <div class="card">
          <h2>
            <span>Structured Trust Artifacts</span>
            <span class="muted" id="artifactCount">0 items</span>
          </h2>
          <div id="artifactList"></div>
          <hr style="border:none;border-top:1px solid var(--border);margin:12px 0;" />
          <h2>Propose Plan Artifact</h2>
          <input id="newArtTitle" placeholder="Plan title (e.g. Zero-downtime auth token rotation)" />
          <textarea id="newArtMarkdown" placeholder="Plan:&#10;1. Inspect token validator&#10;2. Add dual-key verification&#10;3. Run tsc --noEmit"></textarea>
          <button class="primary" id="btnCreateArtifact">Create Plan Trust Artifact</button>
        </div>

        <div class="card">
          <h2>
            <span id="selectedArtTitle">Select an Artifact</span>
            <button class="success" id="btnApproveArtifact" style="display:none;">Approve Plan &amp; Unlock Exec</button>
          </h2>
          <div class="muted" id="selectedArtMeta">Click any artifact on the left to inspect numbered lines and send L-anchored steer() feedback.</div>
          <div class="code-lines" id="selectedArtLines" style="margin-top:10px;"></div>

          <div style="margin-top:12px;">
            <h2>Inline Line-Anchored Steer (Ring 2)</h2>
            <div class="row">
              <div style="flex:1;">
                <label class="muted">Start Line</label>
                <input type="number" id="steerStart" min="1" value="1" />
              </div>
              <div style="flex:1;">
                <label class="muted">End Line</label>
                <input type="number" id="steerEnd" min="1" value="2" />
              </div>
            </div>
            <label class="muted">Review Feedback (delivered via session.steer / nextTurn without prefix mutation)</label>
            <input id="steerComment" placeholder="e.g. Ensure fallback rejects expired signatures before DB lookup" />
            <button class="primary" id="btnSendSteer">Send Inline Steer Feedback</button>
          </div>
        </div>
      </div>
    </section>

    <!-- TAB 2: QUARANTINE & SKILL CURATOR -->
    <section id="tab-quarantine" class="tab-pane">
      <div class="grid-2">
        <div class="card">
          <h2>
            <span>Quarantined &amp; Active Skills Ledger</span>
            <button id="btnLifecyclePass">Run 14d/30d Lifecycle Pass</button>
          </h2>
          <div id="skillsList"></div>
        </div>

        <div class="card">
          <h2>Distill Candidate Skill into <code>.skills-quarantine/</code></h2>
          <div class="muted">Every distilled skill is scanned by <code>skills-guard-v10</code> and held in quarantine until operator approval. Dangerous payloads hard-block promotion.</div>
          <textarea id="distillSkillMd" style="min-height:150px;margin-top:8px;">---
name: safe-db-migration
description: Safe SQLite WAL migration checklist
---
# Safe SQLite Migration
1. Take online page backup via node:sqlite backup() API.
2. Run FTS5 integrity-check before and after schema migration.</textarea>
          <button class="primary" id="btnDistillSkill">Distill &amp; Scan Skill</button>
          <pre class="surface-box" id="skillInspectBox">Select a skill on the left to inspect its SKILL.md and skills-guard-v10 scan findings.</pre>
        </div>
      </div>
    </section>

    <!-- TAB 3: GIT REWIND & WAL -->
    <section id="tab-rewind" class="tab-pane">
      <div class="grid-equal">
        <div class="card">
          <h2>
            <span>Captured <code>/tree</code> Git Checkpoints</span>
            <span class="muted" id="currentLeafBadge">leaf: --</span>
          </h2>
          <div class="muted" style="margin-bottom:10px;">Atomic rewind acquires kernel <code>flock(LOCK_EX|LOCK_NB)</code>, stashes dirty trees under <code>refs/pi-apex/safety/*</code>, and restores exact <code>{kind, hash, mode}</code> state.</div>
          <div id="checkpointList"></div>
        </div>

        <div class="card">
          <h2>Ring 0 Post-Effect WAL Ledger (<code>wal_intents</code>)</h2>
          <div class="muted" style="margin-bottom:10px;">Tracks <code>INTENT_LOGGED -> EXECUTING -> EFFECT_COMMITTED -> TRANSCRIPT_APPENDED</code> and halts on <code>OUTCOME_UNKNOWN</code>.</div>
          <div id="walList"></div>
        </div>
      </div>
    </section>

    <!-- TAB 4: DREAMING, HARNESS2 & SLASH CONSOLE -->
    <section id="tab-evolution" class="tab-pane">
      <div class="grid-equal">
        <div class="card">
          <h2>
            <span><code>surfaces/MEMORY.md</code> (Dreaming &lt;= 300 o200k)</span>
            <button class="primary" id="btnRunDream">Run Dreaming Pass</button>
          </h2>
          <div class="muted" id="memoryMeta">Session-pinned at boot; offline Dreaming updates apply on /new with 0 live prefix drift.</div>
          <div class="meter"><div id="memoryMeter" style="width:0%"></div></div>
          <pre class="surface-box" id="memoryBox"></pre>
        </div>

        <div class="card">
          <h2>
            <span><code>surfaces/EXPERIENCE.md</code> (Harness² 4-Gate &lt;= 220 o200k)</span>
            <span class="badge ok">Issue #94 Protected</span>
          </h2>
          <div class="muted" id="expMeta">Contrastive Propose-Probe-Compose confined strictly to EXPERIENCE.md.</div>
          <div class="meter"><div id="expMeter" style="width:0%"></div></div>
          <pre class="surface-box" id="expBox"></pre>
        </div>
      </div>

      <div class="grid-equal" style="margin-top:16px;">
        <div class="card">
          <h2>Operator Slash Command Console (+0 Schema Tokens)</h2>
          <div class="row">
            <input id="slashInput" value="/doctor" placeholder="/doctor, /plan status, /review uncommitted, /quarantine list, /evolve status" />
            <button class="primary" id="btnRunSlash" style="white-space:nowrap;">Run Command</button>
          </div>
          <pre class="surface-box" id="slashOutput">Ready. Run any /plan, /rewind, /review, /quarantine, /dream, /evolve, or /doctor command.</pre>
        </div>

        <div class="card">
          <h2>Live SSE Session &amp; Control-Plane Event Stream</h2>
          <pre class="surface-box" id="sseLog"></pre>
        </div>
      </div>
    </section>

    <!-- TAB 6 (v2): MODELS, OLLAMA, MULTI-SESSION SWITCHER & CONFINED MCP HUB -->
    <section id="tab-models-mcp" class="tab-pane">
      <div class="grid-equal">
        <div class="card">
          <h2>
            <span>Active Model, <code>apex/auto</code> Router &amp; Cache Telemetry</span>
            <button class="primary" id="btnUseApexAuto">Use apex/auto</button>
          </h2>
          <div class="muted" id="usageTelemetryLine" style="margin-bottom:8px;">Cache hit: 0% | Cost: $0.000000</div>
          <div class="row" style="margin-bottom:10px;">
            <select id="modelCatalogSelect" style="flex:1;padding:7px;background:#090d15;color:#e2e8f0;border:1px solid var(--border);border-radius:6px;"></select>
            <button id="btnSwitchModel">Switch Model</button>
          </div>
          <hr style="border:none;border-top:1px solid var(--border);margin:10px 0;" />
          <h2>Configure Cloud API Key or Local Ollama Endpoint</h2>
          <div class="row" style="margin-bottom:8px;">
            <select id="apiKeyProvider" style="padding:7px;background:#090d15;color:#e2e8f0;border:1px solid var(--border);border-radius:6px;">
              <option value="anthropic">anthropic</option>
              <option value="openai">openai</option>
              <option value="google">google</option>
              <option value="openrouter">openrouter</option>
            </select>
            <input id="apiKeyInput" type="password" placeholder="Runtime API key (stored in memory / auth.json)" />
            <button id="btnSaveApiKey">Set Key</button>
          </div>
          <div class="row">
            <input id="ollamaModelInput" value="qwen2.5-coder:32b" placeholder="Ollama model id (e.g. qwen2.5-coder:32b)" />
            <input id="ollamaUrlInput" placeholder="Optional custom Ollama /v1 URL (blank = default local :11434/v1)" />
            <button class="primary" id="btnRegisterOllama">Register Ollama</button>
          </div>
          <hr style="border:none;border-top:1px solid var(--border);margin:10px 0;" />
          <h2>Saved Workspace Sessions (<code>.harness/sessions/*.jsonl</code>)</h2>
          <div id="sessionsListBox"></div>
        </div>

        <div class="card">
          <h2>
            <span>Confined <code>@earendil-works/pi-mcp</code> Hub (+0 Schema Tokens)</span>
            <span class="badge ok" id="mcpTrustBadge">Trusted</span>
          </h2>
          <div class="muted" style="margin-bottom:8px;">Tools expose as <code>deferred</code>; untrusted repo stdio blocked; tool metadata scanned via <code>skills-guard-v10</code>.</div>
          <div class="row" style="margin-bottom:10px;">
            <input id="mcpNameInput" placeholder="Server name (e.g. local-tools)" />
            <input id="mcpCmdInput" placeholder="Stdio command (e.g. npx or node)" />
            <input id="mcpArgsInput" placeholder="Space-separated args" />
            <button class="primary" id="btnConnectMcpStdio">Connect Stdio</button>
          </div>
          <div id="mcpServersBox" style="margin-bottom:10px;"></div>
          <h2>Audited MCP Tools</h2>
          <div id="mcpToolsBox"></div>
        </div>
      </div>
    </section>

    <!-- TAB 7 (v3): AUTONOMOUS PR PIPELINE, SESSION HANDOFF, PRESETS/BOOKMARKS, CHROMIUM CDP & WORKSPACES -->
    <section id="tab-ring7" class="tab-pane">
      <div class="grid-equal">
        <div class="card">
          <h2>
            <span>6-Stage Autonomous Issue-to-PR Pipeline (<code>/pr</code>)</span>
            <span class="badge accent">apex/&lt;slug&gt;</span>
          </h2>
          <div class="muted" style="margin-bottom:8px;">Branch isolation &rarr; Plan Trust Artifact &rarr; Disjoint worktrees &rarr; Codex/BugBot diff audit &rarr; bwrap CI &rarr; PR bundle.</div>
          <input id="prTitleInput" placeholder="PR title (e.g. Harden session token TTL validation)" />
          <textarea id="prDescInput" rows="2" placeholder="Issue summary &amp; acceptance criteria..."></textarea>
          <div class="row">
            <input id="prTestCmdInput" placeholder="Optional sandboxed CI command (e.g. node --test)" />
            <button class="primary" id="btnRunPrPipeline" style="white-space:nowrap;">Run PR Pipeline</button>
          </div>
          <div id="prRunsListBox" style="margin-top:10px;"></div>
          <pre class="surface-box" id="prBundlePreviewBox" style="margin-top:8px;max-height:180px;display:none;"></pre>
          <hr style="border:none;border-top:1px solid var(--border);margin:12px 0;" />
          <h2>Focused Session Handoff (<code>/handoff</code>) &amp; Zero-Drift Presets (<code>/preset</code>)</h2>
          <div class="row" style="margin-bottom:8px;">
            <input id="handoffGoalInput" placeholder="Goal for clean parentSession-linked child thread..." />
            <button class="primary" id="btnCreateHandoff" style="white-space:nowrap;">Handoff &amp; Switch</button>
          </div>
          <div class="row" style="margin-bottom:8px;">
            <select id="presetSelect" style="flex:1;padding:7px;background:#090d15;color:#e2e8f0;border:1px solid var(--border);border-radius:6px;"></select>
            <button id="btnApplyPreset">Apply Preset (0 Drift)</button>
          </div>
          <div class="row">
            <input id="bookmarkLabelInput" placeholder="Bookmark label for latest turn..." />
            <button id="btnAddBookmark">Bookmark Turn</button>
          </div>
          <div id="bookmarksListBox" style="margin-top:8px;"></div>
        </div>

        <div class="card">
          <h2>
            <span>Live Headless Chromium 156 CDP Browser (<code>@e1</code> ARIA + PNG)</span>
            <span class="badge ok" id="cdpStatusBadge">Checking...</span>
          </h2>
          <div class="row" style="margin-bottom:8px;">
            <input id="browserUrlInput" value="data:text/html,&lt;h1&gt;Pi-Apex Live Chromium CDP&lt;/h1&gt;&lt;button&gt;Deploy&lt;/button&gt;" placeholder="https://... or data:text/html,..." />
            <button class="primary" id="btnCdpNavigate" style="white-space:nowrap;">Open &amp; Snapshot</button>
            <button id="btnCdpScreenshot">PNG Shot</button>
          </div>
          <pre class="surface-box" id="cdpSnapshotBox">Ready. Click Open &amp; Snapshot to query Chromium Accessibility.getFullAXTree.</pre>
          <img id="cdpScreenshotImg" alt="Chromium CDP Screenshot" style="display:none;max-width:100%;margin-top:8px;border:1px solid var(--border);border-radius:6px;" />
          <hr style="border:none;border-top:1px solid var(--border);margin:12px 0;" />
          <h2>Multi-Repository Workspace Switcher</h2>
          <div class="row" style="margin-bottom:8px;">
            <input id="workspaceSwitchInput" placeholder="/path/to/another/git-repo" />
            <button class="primary" id="btnSwitchWorkspace" style="white-space:nowrap;">Switch Repo</button>
          </div>
          <div id="workspacesListBox"></div>
        </div>
      </div>
    </section>

    <!-- TAB 8 (v4): GITHUB QUARANTINE BRIDGE, VS CODE RPC & SWE BENCHMARK SUITE -->
    <section id="tab-ring8" class="tab-pane">
      <div class="grid-equal">
        <div class="card">
          <h2>
            <span>Quarantine-Scanned GitHub Issue Bridge (<code>/issue</code>)</span>
            <span class="badge ok">skills-guard-v10</span>
          </h2>
          <div class="muted" style="margin-bottom:8px;">Scans untrusted GitHub Issue prose &amp; comments before LLM ingestion; blocks prompt-injection / exfil payloads or wraps in <code>&lt;untrusted_github_issue&gt;</code>.</div>
          <input id="ghIssueRefInput" placeholder="https://github.com/owner/repo/issues/42  or  owner/repo#42  or  #42" />
          <div class="row" style="margin-bottom:8px;">
            <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:var(--muted);">
              <input type="checkbox" id="ghAllowQuarantinedChk" style="width:auto;margin:0;" />
              Sanitize quarantined lines instead of hard-blocking
            </label>
          </div>
          <div class="row" style="margin-bottom:10px;">
            <button class="primary" id="btnIngestGhIssue">Scan &amp; Ingest Issue</button>
            <button id="btnRunAutoPrFromIssue">Ingest &amp; Run Self-Healing /pr</button>
          </div>
          <pre class="surface-box" id="ghIssueEnvelopeBox" style="max-height:170px;">Enter a GitHub Issue URL/ref above to inspect its skills-guard-v10 quarantine envelope.</pre>
          <h2 style="margin-top:12px;">Ingested Issue Audit Ledger &amp; Merge Conflicts</h2>
          <div id="ghIngestionsListBox"></div>
        </div>

        <div class="card">
          <h2>
            <span>Personal SWE Eval &amp; Harness² A/B Cache Benchmark (<code>/bench</code>)</span>
            <span class="badge accent">3-Repo bwrap Corpus</span>
          </h2>
          <div class="muted" style="margin-bottom:8px;">Measures pass rate, BugBot/CI self-heal recoveries, <code>o200k_base</code> cache hit %, cost/resolved, and Before vs. After <code>EXPERIENCE.md</code> delta.</div>
          <div class="row" style="margin-bottom:8px;">
            <button class="primary" id="btnRunSweBench">Run 3-Repo A/B SWE Benchmark</button>
          </div>
          <pre class="surface-box" id="sweBenchReportBox" style="max-height:220px;">Click Run 3-Repo A/B SWE Benchmark (or run npm run bench) to evaluate baseline vs. Harness² EXPERIENCE.md.</pre>
          <div id="sweBenchHistoryBox" style="margin-top:8px;"></div>
          <hr style="border:none;border-top:1px solid var(--border);margin:12px 0;" />
          <h2>VS Code &amp; Cursor RPC Extension (<code>extensions/vscode-pi-apex</code>)</h2>
          <div class="muted">Install locally with <code>bash scripts/install-personal.sh --install-vscode</code>. Streams active selection + IDE LSP diagnostics over <code>pi-apex --mode rpc</code> with <strong>0 prefix drift</strong> and automatic <code>.env</code> redaction.</div>
        </div>
      </div>
    </section>

    <!-- TAB 9 (v5): OMNI-CHANNEL GATEWAY, MULTI-AGENT SWARM, EXTERNAL PLUGINS & SELF-LEARNING LEDGER -->
    <section id="tab-ring9" class="tab-pane">
      <div class="grid-equal">
        <div class="card">
          <h2>
            <span>Omni-Channel Messaging Gateway (<code>/gateway</code>, <code>/send</code>)</span>
            <span class="badge ok" id="gatewaySendersBadge">0 paired</span>
          </h2>
          <div class="muted" style="margin-bottom:8px;">WhatsApp (Baileys QR/8-Char Bridge + Meta Cloud HMAC), Telegram, Discord, Slack (Socket Mode + Native Manifest), and Signal (<code>signal-cli</code> JSON-RPC). Fail-closed sender pairing + <code>skills-guard-v10</code> inbound scan.</div>
          <div class="row" style="margin-bottom:8px;">
            <select id="gwPlatformSelect" style="width:auto;">
              <option value="whatsapp_baileys">whatsapp_baileys (Personal QR/Link)</option>
              <option value="whatsapp_cloud">whatsapp_cloud (Meta Graph API)</option>
              <option value="telegram">telegram</option>
              <option value="discord">discord</option>
              <option value="slack">slack</option>
              <option value="signal">signal</option>
            </select>
            <button class="primary" id="btnIssuePairCode">Issue 6-Digit /pair Code</button>
            <button id="btnInitBaileys">WhatsApp Baileys Link Code</button>
          </div>
          <pre class="surface-box" id="gatewayStatusBox" style="max-height:150px;">Loading Omni-Channel Gateway status...</pre>

          <hr style="border:none;border-top:1px solid var(--border);margin:12px 0;" />
          <h2>
            <span>Multi-Agent Swarm &amp; Personas (<code>/agents</code>, <code>/swarm</code>)</span>
            <span class="badge accent" id="personasCountBadge">5 personas</span>
          </h2>
          <input id="swarmGoalInput" placeholder="Goal for Multi-Agent Debate or Supervisor (e.g. Zero-downtime JWT key rotation across API &amp; worker)" />
          <div class="row" style="margin-bottom:8px;">
            <button class="primary" id="btnRunDebateSwarm">Run Multi-Persona Debate</button>
            <button id="btnRunSupervisorSwarm">Run Supervisor-Reviewer</button>
          </div>
          <pre class="surface-box" id="swarmOutputBox" style="max-height:150px;">Select Debate or Supervisor above to orchestrate specialist personas over shared AgentBlackboard.</pre>
        </div>

        <div class="card">
          <h2>
            <span>Hash-Chained Self-Learning Ledger (<code>/ledger</code>)</span>
            <span class="badge ok" id="ledgerChainBadge">Chain: Verified</span>
          </h2>
          <div class="muted" style="margin-bottom:8px;">Append-only SHA-256 chain unifying <code>/pr</code> self-heals, BugBot rules, operator steers, and Harness² <code>EXPERIENCE.md</code> with <strong>0 live prefix drift</strong>.</div>
          <div class="row" style="margin-bottom:6px;">
            <input id="ledgerCueInput" placeholder="Cue (e.g. Validating webhook HMAC headers)" style="margin:0;flex:1;" />
            <input id="ledgerLessonInput" placeholder="Lesson (e.g. Always use timingSafeEqual on equal-length Buffers)" style="margin:0;flex:1;" />
          </div>
          <div class="row" style="margin-bottom:8px;">
            <button class="primary" id="btnRecordLedgerLesson">Append Lesson</button>
            <button id="btnVerifyLedgerChain">Verify SHA-256 Chain</button>
            <button class="success" id="btnMaterializeLedger">Materialize Next-Boot Surfaces</button>
          </div>
          <div id="ledgerEntriesBox" style="max-height:175px;overflow-y:auto;"></div>

          <hr style="border:none;border-top:1px solid var(--border);margin:12px 0;" />
          <h2>
            <span>Quarantine-Scanned External Plugins (<code>/plugin</code>)</span>
            <span class="badge" id="pluginsCountBadge">0 installed</span>
          </h2>
          <div class="row" style="margin-bottom:8px;">
            <input id="pluginSourceDirInput" placeholder="Plugin directory containing apex-plugin.json" style="margin:0;flex:1;" />
            <button class="primary" id="btnInstallPlugin">Audit &amp; Install</button>
          </div>
          <div id="pluginsListBox"></div>
        </div>
      </div>
    </section>
  </main>

  <script>
    let currentState = null;
    let selectedArtifactId = null;

    function showToast(msg, isError = false) {
      const el = document.getElementById("toast");
      el.textContent = msg;
      el.className = "toast visible " + (isError ? "error" : "ok");
    }

    async function apiJson(relUrl, opts = {}) {
      const res = await fetch(relUrl, {
        headers: { "Content-Type": "application/json" },
        ...opts
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || ("HTTP " + res.status));
      }
      return data;
    }

    // Tab switching
    document.querySelectorAll("nav.tabs button").forEach((btn) => {
      btn.addEventListener("click", () => {
        document.querySelectorAll("nav.tabs button").forEach((b) => b.classList.remove("active"));
        document.querySelectorAll(".tab-pane").forEach((p) => p.classList.remove("active"));
        btn.classList.add("active");
        document.getElementById(btn.dataset.tab).classList.add("active");
        refreshStatus();
        refreshV2Panels();
        refreshV3Panels();
        refreshV4Panels();
        refreshV5Panels();
      });
    });

    function renderSelectedArtifact() {
      const linesEl = document.getElementById("selectedArtLines");
      const approveBtn = document.getElementById("btnApproveArtifact");
      const titleEl = document.getElementById("selectedArtTitle");
      const metaEl = document.getElementById("selectedArtMeta");
      if (!currentState) return;
      const art = (currentState.artifacts || []).find((a) => a.artifactId === selectedArtifactId) || (currentState.artifacts || [])[0];
      if (!art) {
        titleEl.textContent = "No Trust Artifacts Yet";
        metaEl.textContent = "Create a Plan Trust Artifact on the left.";
        linesEl.innerHTML = "";
        approveBtn.style.display = "none";
        return;
      }
      selectedArtifactId = art.artifactId;
      titleEl.textContent = art.title + " (" + art.artifactId + ")";
      metaEl.textContent = "kind=" + art.kind + " | status=" + art.status + " | inline comments=" + (art.comments ? art.comments.length : 0);
      approveBtn.style.display = art.kind === "plan" && art.status !== "approved" ? "inline-block" : "none";

      const rawLines = String(art.markdown || "").split("\\n");
      linesEl.innerHTML = "";
      rawLines.forEach((lineText, idx) => {
        const row = document.createElement("div");
        row.className = "code-line";
        row.innerHTML = '<span class="line-num">' + (idx + 1) + '</span><span></span>';
        row.lastChild.textContent = lineText || " ";
        row.addEventListener("click", () => {
          document.getElementById("steerStart").value = String(idx + 1);
          document.getElementById("steerEnd").value = String(idx + 1);
        });
        linesEl.appendChild(row);
      });
    }

    async function refreshStatus() {
      try {
        const st = await apiJson("./api/status");
        currentState = st;

        document.getElementById("workspaceLabel").textContent = st.workspaceRoot + " (session " + st.sessionId.slice(0, 8) + ")";
        document.getElementById("schemaBadge").textContent = "Schema: " + st.prefix.activeSchemaTokens + " o200k";
        document.getElementById("prefixBadge").textContent =
          "Prefix: " + st.prefix.totalPrefixTokens + "/" + st.prefix.maxPrefixTokens + " (" + st.prefix.livePrefixSha256.slice(0, 10) + ")";
        document.getElementById("guardrailsBadge").textContent =
          "GUARDRAILS: " + (st.guardrailsPinVerified ? "Pinned " + st.guardrailsSha256.slice(0, 8) : "TAMPERED");
        const modeEl = document.getElementById("planModeBadge");
        modeEl.textContent = st.planModeActive ? "Mode: PLAN (Read-Only)" : "Mode: EXEC (Confined)";
        modeEl.className = "badge " + (st.planModeActive ? "warn" : "ok");

        // Render Artifacts
        document.getElementById("artifactCount").textContent = st.artifacts.length + " artifact(s)";
        const artList = document.getElementById("artifactList");
        artList.innerHTML = "";
        st.artifacts.forEach((a) => {
          const d = document.createElement("div");
          d.className = "list-item" + (a.artifactId === selectedArtifactId ? " selected" : "");
          const done = (a.todos || []).filter((t) => t.completed).length;
          const total = (a.todos || []).length;
          d.innerHTML =
            "<strong></strong> <span class='badge'>" + a.kind + "</span> <span class='badge " +
            (a.status === "approved" ? "ok" : a.status === "changes_requested" ? "warn" : "accent") +
            "'>" + a.status + "</span>" +
            (total > 0 ? " <span class='muted'>steps " + done + "/" + total + "</span>" : "");
          d.firstChild.textContent = a.title;
          d.addEventListener("click", () => {
            selectedArtifactId = a.artifactId;
            refreshStatus();
          });
          artList.appendChild(d);
        });
        renderSelectedArtifact();

        // Render Skills
        const sList = document.getElementById("skillsList");
        sList.innerHTML = "";
        if (st.skills.length === 0) {
          sList.innerHTML = "<div class='muted'>No skills in ledger yet.</div>";
        }
        st.skills.forEach((s) => {
          const item = document.createElement("div");
          item.className = "list-item";
          const vClass = s.lastScanVerdict === "safe" ? "ok" : s.lastScanVerdict === "caution" ? "warn" : "danger";
          item.innerHTML =
            "<div class='row' style='justify-content:space-between;'>" +
            "<div><strong class='mono'></strong> <span class='badge'>" + s.status + "</span> <span class='badge " + vClass + "'>scan: " + s.lastScanVerdict + "</span></div>" +
            "<div class='row'></div></div><div class='muted' style='margin-top:4px;'></div>";
          item.querySelector("strong").textContent = s.name;
          item.lastChild.textContent = s.description;
          const btnRow = item.querySelectorAll(".row")[1];
          if (s.status === "quarantined") {
            const pBtn = document.createElement("button");
            pBtn.className = s.lastScanVerdict === "dangerous" ? "danger" : "success";
            pBtn.textContent = "Approve & Promote";
            pBtn.addEventListener("click", async (ev) => {
              ev.stopPropagation();
              try {
                const res = await apiJson("./api/quarantine/" + encodeURIComponent(s.name) + "/promote", { method: "POST", body: "{}" });
                showToast("Promoted '" + s.name + "' -> " + res.promotedPath);
                await refreshStatus();
              } catch (err) {
                showToast(err.message, true);
              }
            });
            btnRow.appendChild(pBtn);
          }
          item.addEventListener("click", () => {
            try {
              const parsedScan = JSON.parse(s.lastScanJson || "{}");
              document.getElementById("skillInspectBox").textContent = JSON.stringify(parsedScan, null, 2);
            } catch {
              document.getElementById("skillInspectBox").textContent = s.lastScanJson;
            }
          });
          sList.appendChild(item);
        });

        // Render Checkpoints & WAL
        document.getElementById("currentLeafBadge").textContent = "leaf: " + (st.currentLeafId || "none");
        const cpList = document.getElementById("checkpointList");
        cpList.innerHTML = "";
        if (st.checkpoints.length === 0) {
          cpList.innerHTML = "<div class='muted'>No turn checkpoints recorded in this session yet.</div>";
        }
        st.checkpoints.forEach((cp) => {
          const item = document.createElement("div");
          item.className = "list-item";
          item.innerHTML =
            "<div class='row' style='justify-content:space-between;'>" +
            "<span class='mono'>Turn #" + cp.turn_index + " | leaf=" + cp.leaf_id + " | tree=" + cp.git_tree_oid.slice(0, 10) + "</span>" +
            "<button>Rewind Here</button></div>";
          item.querySelector("button").addEventListener("click", async () => {
            try {
              const rw = await apiJson("./api/rewind", {
                method: "POST",
                body: JSON.stringify({ toLeafId: cp.leaf_id })
              });
              showToast("Rewound workspace to leaf " + cp.leaf_id + " (restored=" + rw.restoredPaths.length + ", deleted=" + rw.deletedPaths.length + ")");
              await refreshStatus();
            } catch (err) {
              showToast(err.message, true);
            }
          });
          cpList.appendChild(item);
        });

        const walList = document.getElementById("walList");
        walList.innerHTML = "";
        if (st.walRows.length === 0) {
          walList.innerHTML = "<div class='muted'>No WAL tool intents recorded yet in current session.</div>";
        }
        st.walRows.forEach((w) => {
          const d = document.createElement("div");
          d.className = "list-item mono";
          d.textContent = w.tool_name + " [" + w.status + "] " + (w.target_path || "");
          walList.appendChild(d);
        });

        // Memory & Experience surfaces
        document.getElementById("memoryBox").textContent = st.surfaces.memoryMd;
        document.getElementById("memoryMeta").textContent =
          "Disk MEMORY.md: " + st.surfaces.memoryTokens + "/300 o200k tokens (frozen boot MEMORY.md: " + st.prefix.bootMemoryTokens + " tokens)";
        document.getElementById("memoryMeter").style.width = Math.min(100, Math.round((st.surfaces.memoryTokens / 300) * 100)) + "%";

        document.getElementById("expBox").textContent = st.surfaces.experienceMd;
        document.getElementById("expMeta").textContent =
          "Disk EXPERIENCE.md: " + st.surfaces.experienceTokens + "/220 o200k tokens";
        document.getElementById("expMeter").style.width = Math.min(100, Math.round((st.surfaces.experienceTokens / 220) * 100)) + "%";
      } catch (err) {
        showToast("Status error: " + err.message, true);
      }
    }

    document.getElementById("btnTogglePlan").addEventListener("click", async () => {
      try {
        const r = await apiJson("./api/plan/toggle", { method: "POST", body: "{}" });
        showToast("Plan Mode is now " + (r.planModeActive ? "ACTIVE (read-only)" : "INACTIVE (exec)"));
        await refreshStatus();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnDoctor").addEventListener("click", async () => {
      try {
        const r = await apiJson("./api/slash", { method: "POST", body: JSON.stringify({ command: "/doctor" }) });
        document.getElementById("slashOutput").textContent = r.markdown;
        showToast("Doctor self-audit completed: ALL HEALTHY");
        await refreshStatus();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnNewSession").addEventListener("click", async () => {
      try {
        const r = await apiJson("./api/new-session", { method: "POST", body: "{}" });
        showToast("Started fresh session " + r.sessionId.slice(0, 8) + " (reloaded staged MEMORY.md; prefix=" + r.prefixSha256.slice(0, 12) + ")");
        await refreshStatus();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnCreateArtifact").addEventListener("click", async () => {
      try {
        const title = document.getElementById("newArtTitle").value.trim() || "Implementation Plan";
        const markdown = document.getElementById("newArtMarkdown").value;
        const art = await apiJson("./api/artifacts", {
          method: "POST",
          body: JSON.stringify({ kind: "plan", title, markdown })
        });
        selectedArtifactId = art.artifactId;
        showToast("Created Plan Trust Artifact " + art.artifactId);
        await refreshStatus();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnApproveArtifact").addEventListener("click", async () => {
      if (!selectedArtifactId) return;
      try {
        await apiJson("./api/artifacts/" + encodeURIComponent(selectedArtifactId) + "/approve", { method: "POST", body: "{}" });
        showToast("Approved " + selectedArtifactId + " and unlocked execution mode.");
        await refreshStatus();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnSendSteer").addEventListener("click", async () => {
      if (!selectedArtifactId) { showToast("Select a Trust Artifact first", true); return; }
      try {
        const lineStart = Number(document.getElementById("steerStart").value || 1);
        const lineEnd = Number(document.getElementById("steerEnd").value || lineStart);
        const comment = document.getElementById("steerComment").value.trim();
        const cmt = await apiJson("./api/artifacts/" + encodeURIComponent(selectedArtifactId) + "/steer", {
          method: "POST",
          body: JSON.stringify({ lineStart, lineEnd, comment })
        });
        showToast("Delivered inline steer comment " + cmt.commentId + " (L" + cmt.lineStart + "-L" + cmt.lineEnd + ")");
        document.getElementById("steerComment").value = "";
        await refreshStatus();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnDistillSkill").addEventListener("click", async () => {
      try {
        const skillMd = document.getElementById("distillSkillMd").value;
        const res = await apiJson("./api/quarantine/distill", {
          method: "POST",
          body: JSON.stringify({ skillMd })
        });
        document.getElementById("skillInspectBox").textContent = JSON.stringify(res.scan, null, 2);
        showToast("Quarantined '" + res.record.name + "' (scan verdict: " + res.scan.verdict + ")");
        await refreshStatus();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnLifecyclePass").addEventListener("click", async () => {
      try {
        const res = await apiJson("./api/quarantine/lifecycle", { method: "POST", body: "{}" });
        showToast("Lifecycle pass: stale=[" + res.markedStale.join(",") + "] archived=[" + res.archived.join(",") + "]");
        await refreshStatus();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnRunDream").addEventListener("click", async () => {
      try {
        const res = await apiJson("./api/dream", { method: "POST", body: "{}" });
        showToast("Dreaming staged " + res.memoryMdTokens + "/300 tokens into MEMORY.md (0 live prefix drift; click '/new Session Reload' to activate!)");
        await refreshStatus();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnRunSlash").addEventListener("click", async () => {
      try {
        const cmd = document.getElementById("slashInput").value.trim();
        if (!cmd) return;
        if (cmd.startsWith("/")) {
          const res = await apiJson("./api/slash", { method: "POST", body: JSON.stringify({ command: cmd }) });
          document.getElementById("slashOutput").textContent = res.markdown || "(command executed)";
        } else {
          const res = await apiJson("./api/prompt", { method: "POST", body: JSON.stringify({ text: cmd, mode: "prompt" }) });
          document.getElementById("slashOutput").textContent = res.replyText || "(prompt completed)";
        }
        await refreshStatus();
      } catch (err) { showToast(err.message, true); }
    });

    async function refreshV2Panels() {
      try {
        const [tr, df, md, ss, mcp] = await Promise.all([
          apiJson("./api/transcript"),
          apiJson("./api/diff"),
          apiJson("./api/models"),
          apiJson("./api/sessions"),
          apiJson("./api/mcp")
        ]);

        // Header model + cache hit badge
        const hitPct = tr.usage ? tr.usage.cacheHitRatePct : 0;
        const costUsd = tr.usage ? tr.usage.totalCostUsd : 0;
        document.getElementById("modelCacheBadge").textContent =
          "Model: " + (tr.activeModel || "none") + " | Cache: " + hitPct + "%";
        document.getElementById("usageTelemetryLine").textContent =
          "Active: " + tr.activeModel + " | Cache Hit: " + hitPct + "% | Input: " +
          (tr.usage ? tr.usage.inputTokens : 0) + " | Output: " +
          (tr.usage ? tr.usage.outputTokens : 0) + " | Cost: $" + Number(costUsd).toFixed(6);
        document.getElementById("chatStreamingBadge").textContent = tr.isStreaming ? "STREAMING..." : "idle";

        // 1. Transcript
        const chatBox = document.getElementById("chatTranscriptBox");
        chatBox.innerHTML = "";
        if (!tr.messages || tr.messages.length === 0) {
          chatBox.innerHTML = "<div class='muted'>No messages in this session yet. Send a prompt below or run /doctor!</div>";
        } else {
          tr.messages.forEach((m) => {
            const card = document.createElement("div");
            card.className = "list-item";
            const badgeClass = m.role === "user" ? "accent" : m.role === "assistant" ? "ok" : m.isError ? "danger" : "";
            const header = document.createElement("div");
            header.innerHTML =
              "<span class='badge " + badgeClass + "'>" + m.role + (m.toolName ? ":" + m.toolName : "") + "</span> " +
              (m.model ? "<span class='muted mono'>" + m.model + "</span>" : "");
            const body = document.createElement("pre");
            body.style.cssText = "margin:6px 0 0 0;white-space:pre-wrap;font-size:12px;color:#e2e8f0;";
            let fullTxt = m.text || "";
            if (m.toolCalls && m.toolCalls.length > 0) {
              fullTxt += (fullTxt ? "\\n" : "") + m.toolCalls.map((tc) => "[toolCall " + tc.name + "] " + tc.argsPreview).join("\\n");
            }
            body.textContent = fullTxt || "(empty)";
            card.appendChild(header);
            card.appendChild(body);
            chatBox.appendChild(card);
          });
          chatBox.scrollTop = chatBox.scrollHeight;
        }

        // 2. Git Diff Viewer
        document.getElementById("diffStatusSummary").textContent =
          df.changedFilesCount > 0
            ? df.changedFilesCount + " modified/untracked file(s): " + df.statusLines.join(" | ")
            : "Clean working tree (0 uncommitted changes).";
        document.getElementById("diffViewerBox").textContent =
          df.diffText && df.diffText.trim() ? df.diffText : "(no uncommitted diff against HEAD)";

        // 3. Model catalog selector
        const sel = document.getElementById("modelCatalogSelect");
        sel.innerHTML = "";
        (md.models || []).forEach((m) => {
          const opt = document.createElement("option");
          opt.value = m.provider + ":::" + m.id;
          opt.textContent = m.provider + "/" + m.id + (m.isVirtual ? " [virtual router]" : "");
          if (md.activeModel === m.provider + "/" + m.id) opt.selected = true;
          sel.appendChild(opt);
        });

        // 4. Saved Workspace Sessions
        const sBox = document.getElementById("sessionsListBox");
        sBox.innerHTML = "";
        if (!ss.sessions || ss.sessions.length === 0) {
          sBox.innerHTML = "<div class='muted'>Current session is active (saved on first message).</div>";
        } else {
          ss.sessions.slice(0, 12).forEach((s) => {
            const row = document.createElement("div");
            row.className = "list-item row";
            row.style.justifyContent = "space-between";
            const info = document.createElement("div");
            info.innerHTML =
              "<strong class='mono'>" + s.id.slice(0, 8) + "</strong> " +
              (s.isCurrent ? "<span class='badge ok'>current</span> " : "") +
              "<span class='muted'>(" + s.messageCount + " msgs)</span>";
            const sub = document.createElement("div");
            sub.className = "muted";
            sub.textContent = s.firstMessage || "(no prompt yet)";
            info.appendChild(sub);
            row.appendChild(info);
            if (!s.isCurrent) {
              const b = document.createElement("button");
              b.textContent = "Switch";
              b.addEventListener("click", async () => {
                try {
                  await apiJson("./api/sessions", {
                    method: "POST",
                    body: JSON.stringify({ sessionPath: s.path })
                  });
                  showToast("Switched to session " + s.id.slice(0, 8));
                  await refreshStatus();
                } catch (err) { showToast(err.message, true); }
              });
              row.appendChild(b);
            }
            sBox.appendChild(row);
          });
        }

        // 5. Confined MCP Hub
        document.getElementById("mcpTrustBadge").textContent = mcp.workspaceTrusted ? "Workspace Trusted" : "Untrusted (Stdio Blocked)";
        document.getElementById("mcpTrustBadge").className = "badge " + (mcp.workspaceTrusted ? "ok" : "warn");
        const mSrv = document.getElementById("mcpServersBox");
        mSrv.innerHTML = "";
        if (!mcp.servers || mcp.servers.length === 0) {
          mSrv.innerHTML = "<div class='muted'>No MCP servers connected (+0 active schema tokens).</div>";
        } else {
          mcp.servers.forEach((sv) => {
            const item = document.createElement("div");
            item.className = "list-item row";
            item.style.justifyContent = "space-between";
            const left = document.createElement("div");
            left.textContent = sv.name + " [" + sv.transportKind + "] safe=" + sv.safeTools + " poisoned=" + sv.poisonedTools;
            const dBtn = document.createElement("button");
            dBtn.className = "danger";
            dBtn.textContent = "Disconnect";
            dBtn.addEventListener("click", async () => {
              try {
                await apiJson("./api/mcp", { method: "POST", body: JSON.stringify({ action: "disconnect", name: sv.name }) });
                await refreshV2Panels();
              } catch (err) { showToast(err.message, true); }
            });
            item.appendChild(left);
            item.appendChild(dBtn);
            mSrv.appendChild(item);
          });
        }
        const mTools = document.getElementById("mcpToolsBox");
        mTools.innerHTML = "";
        (mcp.tools || []).forEach((t) => {
          const d = document.createElement("div");
          d.className = "list-item";
          d.textContent = t.serverName + "/" + t.name + " [scan=" + t.scanVerdict + (t.poisoned ? " BLOCKED" : "") + "] - " + t.description;
          mTools.appendChild(d);
        });
      } catch {}
    }

    document.getElementById("btnSendPrompt").addEventListener("click", async () => {
      try {
        const input = document.getElementById("chatPromptInput");
        const txt = input.value.trim();
        if (!txt) return;
        input.value = "";
        if (txt.startsWith("/")) {
          await apiJson("./api/slash", { method: "POST", body: JSON.stringify({ command: txt }) });
        } else {
          await apiJson("./api/prompt", { method: "POST", body: JSON.stringify({ text: txt, mode: "prompt" }) });
        }
        document.getElementById("liveStreamBox").style.display = "none";
        document.getElementById("liveStreamBox").textContent = "";
        await refreshStatus();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnSteerPrompt").addEventListener("click", async () => {
      try {
        const input = document.getElementById("chatPromptInput");
        const txt = input.value.trim();
        if (!txt) return;
        input.value = "";
        await apiJson("./api/prompt", { method: "POST", body: JSON.stringify({ text: txt, mode: "steer" }) });
        showToast("Delivered mid-turn steer message");
        await refreshStatus();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnAbortTurn").addEventListener("click", async () => {
      try {
        await apiJson("./api/abort", { method: "POST", body: "{}" });
        showToast("Aborted in-flight turn");
        await refreshStatus();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnRefreshDiff").addEventListener("click", () => refreshV2Panels());
    document.getElementById("btnRunBugBot").addEventListener("click", async () => {
      try {
        const res = await apiJson("./api/slash", { method: "POST", body: JSON.stringify({ command: "/review uncommitted" }) });
        document.getElementById("diffViewerBox").textContent = res.markdown || "(BugBot clean)";
        showToast("BugBot diff review completed");
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnUseApexAuto").addEventListener("click", async () => {
      try {
        await apiJson("./api/models", { method: "POST", body: JSON.stringify({ action: "set_model", provider: "apex", modelId: "auto" }) });
        showToast("Switched active model to apex/auto (Plan-Strong / Implement-Fast)");
        await refreshV2Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnSwitchModel").addEventListener("click", async () => {
      try {
        const val = document.getElementById("modelCatalogSelect").value;
        if (!val) return;
        const parts = val.split(":::");
        await apiJson("./api/models", { method: "POST", body: JSON.stringify({ action: "set_model", provider: parts[0], modelId: parts[1] }) });
        showToast("Switched model to " + parts[0] + "/" + parts[1]);
        await refreshV2Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnSaveApiKey").addEventListener("click", async () => {
      try {
        const provider = document.getElementById("apiKeyProvider").value;
        const apiKey = document.getElementById("apiKeyInput").value.trim();
        await apiJson("./api/models", { method: "POST", body: JSON.stringify({ action: "set_api_key", provider, apiKey }) });
        document.getElementById("apiKeyInput").value = "";
        showToast("Configured runtime API key for " + provider);
        await refreshV2Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnRegisterOllama").addEventListener("click", async () => {
      try {
        const modelId = document.getElementById("ollamaModelInput").value.trim();
        const baseUrl = document.getElementById("ollamaUrlInput").value.trim();
        const res = await apiJson("./api/models", {
          method: "POST",
          body: JSON.stringify({ action: "register_ollama", modelId, baseUrl, activate: true })
        });
        showToast("Registered & activated local Ollama model: " + res.activeModel);
        await refreshV2Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnConnectMcpStdio").addEventListener("click", async () => {
      try {
        const name = document.getElementById("mcpNameInput").value.trim();
        const command = document.getElementById("mcpCmdInput").value.trim();
        const rawArgs = document.getElementById("mcpArgsInput").value.trim();
        const args = rawArgs ? rawArgs.split(/\\s+/) : [];
        const res = await apiJson("./api/mcp", {
          method: "POST",
          body: JSON.stringify({ action: "connect_stdio", name, command, args })
        });
        showToast("Connected MCP server '" + res.summary.name + "' (" + res.summary.safeTools + " safe tools)");
        await refreshV2Panels();
      } catch (err) { showToast(err.message, true); }
    });

    async function refreshV3Panels() {
      try {
        const [prs, pres, brw, wss] = await Promise.all([
          apiJson("./api/pr-pipeline"),
          apiJson("./api/presets"),
          apiJson("./api/browser"),
          apiJson("./api/workspaces")
        ]);

        // 1. PR Runs
        const prBox = document.getElementById("prRunsListBox");
        const prPreview = document.getElementById("prBundlePreviewBox");
        prBox.innerHTML = "";
        const prRuns = prs.runs || [];
        if (prRuns.length === 0) {
          prBox.innerHTML = "<div class='muted'>No PR runs yet. Enter a title above and click Run PR Pipeline.</div>";
          prPreview.style.display = "none";
        } else {
          prRuns.slice(0, 8).forEach((r, idx) => {
            const item = document.createElement("div");
            item.className = "list-item";
            item.style.cursor = "pointer";
            item.textContent = "[" + r.status.toUpperCase() + "] " + r.branchName + " -> " + r.baseBranch + " (" + r.title + ")";
            item.addEventListener("click", () => {
              prPreview.style.display = "block";
              prPreview.textContent = r.markdown || r.ghCommand || "";
            });
            prBox.appendChild(item);
            if (idx === 0 && !prPreview.textContent) {
              prPreview.style.display = "block";
              prPreview.textContent = r.markdown || r.ghCommand || "";
            }
          });
        }

        // 2. Presets & Bookmarks
        const pSel = document.getElementById("presetSelect");
        pSel.innerHTML = "";
        const clearOpt = document.createElement("option");
        clearOpt.value = "clear";
        clearOpt.textContent = "(none — default core posture)";
        pSel.appendChild(clearOpt);
        (pres.presets || []).forEach((p) => {
          const opt = document.createElement("option");
          opt.value = p.name;
          opt.textContent = p.name + (p.active ? " [ACTIVE]" : "") + " — " + p.summary;
          if (p.active) opt.selected = true;
          pSel.appendChild(opt);
        });

        const bmBox = document.getElementById("bookmarksListBox");
        bmBox.innerHTML = "";
        (pres.bookmarks || []).forEach((b) => {
          const d = document.createElement("div");
          d.className = "list-item";
          d.textContent = "[" + b.label + "] entry=" + b.entryId.slice(0, 8) + " — " + b.preview;
          bmBox.appendChild(d);
        });

        // 3. Chromium CDP Status
        const cdpBadge = document.getElementById("cdpStatusBadge");
        cdpBadge.textContent = brw.hasLocalChromium
          ? (brw.isCdpActive ? "Chromium CDP Live" : "Chromium Ready")
          : "Virtual DOM Fallback";

        // 4. Workspaces
        const wsBox = document.getElementById("workspacesListBox");
        wsBox.innerHTML = "";
        (wss.workspaces || []).forEach((w) => {
          const row = document.createElement("div");
          row.className = "list-item row";
          row.style.justifyContent = "space-between";
          const span = document.createElement("span");
          span.className = "mono";
          span.textContent = w.path + (w.active ? " [ACTIVE]" : "");
          row.appendChild(span);
          if (!w.active) {
            const b = document.createElement("button");
            b.textContent = "Activate";
            b.addEventListener("click", async () => {
              try {
                await apiJson("./api/workspaces", {
                  method: "POST",
                  body: JSON.stringify({ action: "switch", workspaceRoot: w.path })
                });
                showToast("Switched active workspace to " + w.path);
                await refreshStatus();
                await refreshV2Panels();
                await refreshV3Panels();
              } catch (err) { showToast(err.message, true); }
            });
            row.appendChild(b);
          }
          wsBox.appendChild(row);
        });
      } catch {}
    }

    document.getElementById("btnRunPrPipeline").addEventListener("click", async () => {
      try {
        const title = document.getElementById("prTitleInput").value.trim();
        const issueDescription = document.getElementById("prDescInput").value.trim() || title;
        const testCommand = document.getElementById("prTestCmdInput").value.trim();
        const res = await apiJson("./api/pr-pipeline", {
          method: "POST",
          body: JSON.stringify({ title, issueDescription, testCommand: testCommand || undefined })
        });
        showToast("PR Pipeline finished: " + res.branchName + " [" + res.status + "]");
        await refreshStatus();
        await refreshV3Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnCreateHandoff").addEventListener("click", async () => {
      try {
        const goal = document.getElementById("handoffGoalInput").value.trim();
        if (!goal) return;
        const res = await apiJson("./api/handoff", {
          method: "POST",
          body: JSON.stringify({ goal, switchNow: true })
        });
        document.getElementById("handoffGoalInput").value = "";
        showToast("Handed off & switched to session " + res.childSessionId.slice(0, 8));
        await refreshStatus();
        await refreshV2Panels();
        await refreshV3Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnApplyPreset").addEventListener("click", async () => {
      try {
        const name = document.getElementById("presetSelect").value;
        const res = await apiJson("./api/presets", {
          method: "POST",
          body: JSON.stringify({ action: "apply_preset", name })
        });
        showToast("Preset updated (" + (res.activated || "cleared") + ", 0 prefix drift)");
        await refreshStatus();
        await refreshV3Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnAddBookmark").addEventListener("click", async () => {
      try {
        const label = document.getElementById("bookmarkLabelInput").value.trim();
        const res = await apiJson("./api/presets", {
          method: "POST",
          body: JSON.stringify({ action: "add_bookmark", label })
        });
        document.getElementById("bookmarkLabelInput").value = "";
        showToast("Bookmarked turn as '" + res.label + "'");
        await refreshV3Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnCdpNavigate").addEventListener("click", async () => {
      try {
        const url = document.getElementById("browserUrlInput").value.trim();
        await apiJson("./api/browser", {
          method: "POST",
          body: JSON.stringify({ action: "navigate", backend: "cdp", url })
        });
        const snap = await apiJson("./api/browser", {
          method: "POST",
          body: JSON.stringify({ action: "snapshot", backend: "cdp" })
        });
        document.getElementById("cdpSnapshotBox").textContent =
          "[" + snap.snapshotId + " rev=" + snap.domRevision + "]\\n" + snap.snapshot;
        await refreshV3Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnCdpScreenshot").addEventListener("click", async () => {
      try {
        const shot = await apiJson("./api/browser", {
          method: "POST",
          body: JSON.stringify({ action: "screenshot", backend: "cdp" })
        });
        const img = document.getElementById("cdpScreenshotImg");
        img.src = "data:" + shot.mimeType + ";base64," + shot.data;
        img.style.display = "block";
        showToast("Captured live Chromium CDP PNG screenshot");
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnSwitchWorkspace").addEventListener("click", async () => {
      try {
        const workspaceRoot = document.getElementById("workspaceSwitchInput").value.trim();
        if (!workspaceRoot) return;
        const sw = await apiJson("./api/workspaces", {
          method: "POST",
          body: JSON.stringify({ action: "switch", workspaceRoot })
        });
        document.getElementById("workspaceSwitchInput").value = "";
        showToast("Switched active repo to " + sw.workspaceRoot);
        await refreshStatus();
        await refreshV2Panels();
        await refreshV3Panels();
        await refreshV4Panels();
      } catch (err) { showToast(err.message, true); }
    });

    async function refreshV4Panels() {
      try {
        const [ghi, bch] = await Promise.all([
          apiJson("./api/github-issue"),
          apiJson("./api/bench")
        ]);
        const gBox = document.getElementById("ghIngestionsListBox");
        gBox.innerHTML = "";
        const items = ghi.ingestions || [];
        const conflicts = ghi.conflicts || [];
        if (conflicts.length > 0) {
          const cDiv = document.createElement("div");
          cDiv.className = "list-item";
          cDiv.textContent = "[CONFLICT] " + conflicts.length + " unresolved Git merge conflict block(s) detected";
          gBox.appendChild(cDiv);
        }
        if (items.length === 0 && conflicts.length === 0) {
          gBox.innerHTML = "<div class='muted'>No GitHub issues ingested yet and 0 Git merge conflicts.</div>";
        } else {
          items.slice(0, 8).forEach((it) => {
            const d = document.createElement("div");
            d.className = "list-item";
            d.textContent = it.repo + "#" + it.number + " [scan=" + it.scanVerdict + (it.sanitized ? ", sanitized" : "") + "] — " + it.title;
            gBox.appendChild(d);
          });
        }

        const bBox = document.getElementById("sweBenchHistoryBox");
        bBox.innerHTML = "";
        const runs = bch.benchmarks || [];
        runs.slice(0, 6).forEach((b) => {
          const d = document.createElement("div");
          d.className = "list-item";
          d.textContent = b.benchId + " | baseline=" + b.baselinePassRatePct + "%" +
            (b.evolvedPassRatePct !== undefined ? (" -> evolved=" + b.evolvedPassRatePct + "% (repairsSaved=" + (b.repairAttemptsSaved || 0) + ")") : "") +
            " | cacheHit=" + b.baselineCacheHitPct + "%";
          bBox.appendChild(d);
        });
      } catch {}
    }

    document.getElementById("btnIngestGhIssue").addEventListener("click", async () => {
      try {
        const refOrUrl = document.getElementById("ghIssueRefInput").value.trim();
        const allowQuarantinedIssue = document.getElementById("ghAllowQuarantinedChk").checked;
        if (!refOrUrl) return;
        const res = await apiJson("./api/github-issue", {
          method: "POST",
          body: JSON.stringify({ refOrUrl, allowQuarantinedIssue, runPr: false })
        });
        document.getElementById("ghIssueEnvelopeBox").textContent = res.isolatedPromptEnvelope;
        showToast("Ingested " + res.repo + "#" + res.number + " (scan=" + res.scanVerdict + ")");
        await refreshV4Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnRunAutoPrFromIssue").addEventListener("click", async () => {
      try {
        const refOrUrl = document.getElementById("ghIssueRefInput").value.trim();
        const allowQuarantinedIssue = document.getElementById("ghAllowQuarantinedChk").checked;
        if (!refOrUrl) return;
        const res = await apiJson("./api/github-issue", {
          method: "POST",
          body: JSON.stringify({ refOrUrl, allowQuarantinedIssue, runPr: true, liveLlm: false })
        });
        document.getElementById("ghIssueEnvelopeBox").textContent = res.prReceipt.prMarkdown;
        showToast("Completed Issue-to-PR: " + res.prReceipt.branchName + " [" + res.prReceipt.status + "]");
        await refreshV3Panels();
        await refreshV4Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnRunSweBench").addEventListener("click", async () => {
      try {
        document.getElementById("sweBenchReportBox").textContent = "Running 3-Repo bwrap SWE Benchmark (baseline vs. Harness² EXPERIENCE.md)...";
        const res = await apiJson("./api/bench", {
          method: "POST",
          body: JSON.stringify({ compareExperienceAb: true })
        });
        document.getElementById("sweBenchReportBox").textContent = res.markdownReport;
        showToast("SWE Benchmark complete: evolved pass=" + (res.evolved ? res.evolved.passRatePct : res.baseline.passRatePct) + "%");
        await refreshV4Panels();
      } catch (err) { showToast(err.message, true); }
    });

    async function refreshV5Panels() {
      try {
        const [gwData, swarmData, plugData, ledData] = await Promise.all([
          apiJson("./api/gateway"),
          apiJson("./api/swarm"),
          apiJson("./api/plugins"),
          apiJson("./api/ledger")
        ]);

        document.getElementById("gatewaySendersBadge").textContent =
          gwData.status.allowedSendersCount + " paired";
        const gwLines = gwData.status.platforms.map(
          (p) => p.platform + " [" + (p.configured ? "READY" : "OFF") + "] -> " + p.mode
        );
        document.getElementById("gatewayStatusBox").textContent = gwLines.join("\\n");

        document.getElementById("personasCountBadge").textContent =
          swarmData.personas.length + " personas";
        if (swarmData.recentRuns && swarmData.recentRuns.length > 0) {
          const latest = swarmData.recentRuns[0];
          document.getElementById("swarmOutputBox").textContent =
            "[" + latest.runId + " | " + latest.topology + " | waves=" + latest.wavesExecuted + "]\\n" +
            (latest.winningSummary || "");
        }

        const chainEl = document.getElementById("ledgerChainBadge");
        chainEl.textContent = ledData.integrity.valid
          ? "Chain: Verified (#" + ledData.integrity.totalEntries + " " + ledData.integrity.headHash.slice(0, 8) + ")"
          : "Chain: TAMPERED";
        chainEl.className = "badge " + (ledData.integrity.valid ? "ok" : "danger");

        const ledBox = document.getElementById("ledgerEntriesBox");
        ledBox.innerHTML = "";
        if (!ledData.entries || ledData.entries.length === 0) {
          ledBox.innerHTML = "<div class='muted'>No ledger entries yet.</div>";
        } else {
          ledData.entries.slice(0, 12).forEach((e) => {
            const row = document.createElement("div");
            row.className = "list-item";
            row.innerHTML =
              "<div class='row' style='justify-content:space-between;'>" +
              "<span class='mono'>#" + e.seq + " " + e.entryId + " [" + e.status + " | conf=" + e.confidence + "]</span>" +
              "<span class='mono muted'>" + e.entryHash.slice(0, 10) + "</span></div>" +
              "<div class='muted' style='margin-top:3px;'></div>";
            row.lastChild.textContent = e.cue + " -> " + e.lesson;
            ledBox.appendChild(row);
          });
        }

        document.getElementById("pluginsCountBadge").textContent =
          plugData.plugins.length + " installed";
        const pBox = document.getElementById("pluginsListBox");
        pBox.innerHTML = "";
        if (!plugData.plugins || plugData.plugins.length === 0) {
          pBox.innerHTML = "<div class='muted'>No external plugins installed yet (active schema stays strictly 1,073 o200k tokens).</div>";
        } else {
          plugData.plugins.forEach((p) => {
            const d = document.createElement("div");
            d.className = "list-item";
            d.textContent =
              p.id + "@" + p.version + " [" + (p.enabled ? "ENABLED" : "DISABLED") + " | scan=" + p.scanVerdict + "] tools=" +
              (p.tools.map((t) => t.qualifiedName).join(", ") || "none");
            pBox.appendChild(d);
          });
        }
      } catch {}
    }

    document.getElementById("btnIssuePairCode").addEventListener("click", async () => {
      try {
        const platform = document.getElementById("gwPlatformSelect").value;
        const tok = await apiJson("./api/gateway", {
          method: "POST",
          body: JSON.stringify({ action: "issue_pair", platform })
        });
        document.getElementById("gatewayStatusBox").textContent =
          "Issued 1-time pairing code for " + tok.platform + ": /pair " + tok.code + " (valid 10m)";
        showToast("Pairing code for " + tok.platform + ": " + tok.code);
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnInitBaileys").addEventListener("click", async () => {
      try {
        const st = await apiJson("./api/gateway", {
          method: "POST",
          body: JSON.stringify({ action: "pair_whatsapp_baileys" })
        });
        document.getElementById("gatewayStatusBox").textContent =
          "WhatsApp Personal Baileys Link Code: " + st.eightCharLinkCode + "\\nQR URI: " + st.qrPayload;
        showToast("WhatsApp link code: " + st.eightCharLinkCode);
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnRunDebateSwarm").addEventListener("click", async () => {
      try {
        const goal = document.getElementById("swarmGoalInput").value.trim() || "Design zero-downtime key rotation";
        document.getElementById("swarmOutputBox").textContent = "Running Multi-Persona Debate...";
        const run = await apiJson("./api/swarm", {
          method: "POST",
          body: JSON.stringify({ topology: "debate", goal })
        });
        document.getElementById("swarmOutputBox").textContent =
          "[" + run.runId + " | debate | waves=" + run.wavesExecuted + "]\\n" + (run.winningSummary || "");
        showToast("Debate complete (" + run.runId + ")");
        await refreshV5Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnRunSupervisorSwarm").addEventListener("click", async () => {
      try {
        const goal = document.getElementById("swarmGoalInput").value.trim() || "Audit workspace security posture";
        document.getElementById("swarmOutputBox").textContent = "Running Supervisor-Reviewer orchestration...";
        const run = await apiJson("./api/swarm", {
          method: "POST",
          body: JSON.stringify({ topology: "supervisor", goal })
        });
        document.getElementById("swarmOutputBox").textContent =
          "[" + run.runId + " | supervisor | waves=" + run.wavesExecuted + "]\\n" + (run.winningSummary || "");
        showToast("Supervisor run complete (" + run.runId + ")");
        await refreshV5Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnRecordLedgerLesson").addEventListener("click", async () => {
      try {
        const cue = document.getElementById("ledgerCueInput").value.trim();
        const lesson = document.getElementById("ledgerLessonInput").value.trim();
        const entry = await apiJson("./api/ledger", {
          method: "POST",
          body: JSON.stringify({ action: "record", cue, lesson })
        });
        document.getElementById("ledgerCueInput").value = "";
        document.getElementById("ledgerLessonInput").value = "";
        showToast("Recorded #" + entry.seq + " (" + entry.entryId + ")");
        await refreshV5Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnVerifyLedgerChain").addEventListener("click", async () => {
      try {
        const rep = await apiJson("./api/ledger", {
          method: "POST",
          body: JSON.stringify({ action: "verify" })
        });
        showToast(rep.valid ? "SHA-256 Chain VERIFIED (" + rep.totalEntries + " entries)" : ("TAMPER: " + rep.reason), !rep.valid);
        await refreshV5Panels();
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnMaterializeLedger").addEventListener("click", async () => {
      try {
        const mat = await apiJson("./api/ledger", {
          method: "POST",
          body: JSON.stringify({ action: "materialize" })
        });
        showToast("Materialized " + mat.experienceCount + " cues (" + mat.experienceTokens + "/220 o200k tokens) for next boot");
      } catch (err) { showToast(err.message, true); }
    });

    document.getElementById("btnInstallPlugin").addEventListener("click", async () => {
      try {
        const sourceDir = document.getElementById("pluginSourceDirInput").value.trim();
        const p = await apiJson("./api/plugins", {
          method: "POST",
          body: JSON.stringify({ action: "install", sourceDir })
        });
        showToast("Installed plugin " + p.id + "@" + p.version + " (+0 active schema tokens)");
        await refreshV5Panels();
      } catch (err) { showToast(err.message, true); }
    });

    // Live SSE connection (strictly relative URL './api/events')
    const sse = new EventSource("./api/events");
    const sseLog = document.getElementById("sseLog");
    const liveStreamBox = document.getElementById("liveStreamBox");
    sse.onopen = () => {
      document.getElementById("sseDot").style.background = "#22c55e";
    };
    sse.onerror = () => {
      document.getElementById("sseDot").style.background = "#f59e0b";
    };
    sse.onmessage = (ev) => {
      const line = "[" + new Date().toISOString().slice(11, 19) + "] " + ev.data;
      sseLog.textContent = (line + "\\n" + sseLog.textContent).slice(0, 8000);
      try {
        const parsed = JSON.parse(ev.data);
        if (parsed.type === "message_update" && parsed.assistantMessageEvent && parsed.assistantMessageEvent.delta) {
          liveStreamBox.style.display = "block";
          liveStreamBox.textContent += parsed.assistantMessageEvent.delta;
        }
        if (parsed.type === "agent_end" || parsed.type === "cockpit_refresh" || parsed.type === "turn_end") {
          if (parsed.type === "agent_end") {
            liveStreamBox.style.display = "none";
            liveStreamBox.textContent = "";
          }
          refreshStatus();
          refreshV2Panels();
          refreshV3Panels();
          refreshV4Panels();
          refreshV5Panels();
        }
      } catch {}
    };

    refreshStatus();
    refreshV2Panels();
    refreshV3Panels();
    refreshV4Panels();
    refreshV5Panels();
  </script>
</body>
</html>`;
  if (!_validatedInlineScript) {
    const match = html.match(/<script>([\s\S]*?)<\/script>/);
    if (match && match[1]) {
      // Fail-fast syntax guard: catches any unescaped newline or JS syntax error immediately.
      new Function(match[1]);
    }
    _validatedInlineScript = true;
  }
  return html;
}
