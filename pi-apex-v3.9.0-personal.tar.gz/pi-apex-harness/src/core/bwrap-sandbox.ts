import { execFileSync, spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import type { BashOperations } from "@earendil-works/pi-coding-agent";
import type { SandboxMode } from "../types.ts";
import {
  auditGitHistoryForSecretPaths,
  DEFAULT_UNMASKED_SECRET_EXCEPTIONS,
  scanWorkspaceSecretsAndHardlinks
} from "./safe-path.ts";

export class SandboxUnavailableError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "SandboxUnavailableError";
  }
}

export interface BwrapSandboxConfig {
  workspaceRoot: string;
  mode?: SandboxMode;
  unshareNet?: boolean;
  allowUnsandboxedDev?: boolean;
  unmaskedSecretExceptions?: readonly string[];
  /**
   * Controls Git object/reflog isolation inside `bwrap` (Reviewer #5 Issue #3 Fix):
   * - `"always"` (SAFE DEFAULT): unconditionally resolves the actual `gitDir`, `commonDir` (including
   *   linked `git worktree` pointers), `objects` dirs (including `objects/info/alternates`), and `logs`
   *   dirs, and overlays `--tmpfs` over all object/log directories inside `bwrap`. Protects reachable,
   *   reflog-only, AND unreachable/dangling secret blobs.
   * - `"on-historical-secret"`: opt-in weaker mode scanning only reachable `git log --all` + `git ls-files`
   *   (does NOT detect unreachable/dangling blobs prior to `git gc --prune=now`).
   * - `"expose-unsafe"`: explicit operator opt-in when full inside-sandbox `git` history access is required.
   */
  isolateGitObjectsMode?: "always" | "on-historical-secret" | "expose-unsafe";
  extraWritablePaths?: string[];
  extraReadOnlyPaths?: string[];
}

let cachedBwrapProbe: { ok: boolean; reason?: string } | null = null;

export function probeBwrapFunctional(): { ok: boolean; reason?: string } {
  if (cachedBwrapProbe) return cachedBwrapProbe;
  try {
    const out = execFileSync(
      "bwrap",
      [
        "--ro-bind", "/usr", "/usr",
        "--ro-bind", "/bin", "/bin",
        "--ro-bind", "/lib", "/lib",
        "--ro-bind-try", "/lib64", "/lib64",
        "--proc", "/proc",
        "--dev", "/dev",
        "--tmpfs", "/tmp",
        "--unshare-net",
        "--unshare-pid",
        "--die-with-parent",
        "--clearenv",
        "--setenv", "PATH", "/usr/bin:/bin",
        "--", "/bin/echo", "BWRAP_PROBE_OK"
      ],
      { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], timeout: 5000 }
    ).trim();
    cachedBwrapProbe = out === "BWRAP_PROBE_OK" ? { ok: true } : { ok: false, reason: `Unexpected probe: ${out}` };
  } catch (err) {
    cachedBwrapProbe = { ok: false, reason: err instanceof Error ? err.message : String(err) };
  }
  return cachedBwrapProbe;
}

export interface ResolvedGitLayout {
  isGitRepo: boolean;
  isLinkedWorktree: boolean;
  gitDir: string | null;
  commonDir: string | null;
  objectsDirs: string[];
  logsDirs: string[];
  indexFiles: string[];
  readOnlyControlPaths: string[];
}

/**
 * Resolves actual `gitDir`, `commonDir` (`commondir` in linked worktrees), `objects` directories
 * (including `objects/info/alternates`), `logs`, `hooks`, and `config` paths across both standard
 * repositories and linked `git worktree` checkouts.
 */
export function resolveGitRepositoryLayout(workspaceRoot: string): ResolvedGitLayout {
  const dotGit = path.join(workspaceRoot, ".git");
  if (!fs.existsSync(dotGit)) {
    return {
      isGitRepo: false,
      isLinkedWorktree: false,
      gitDir: null,
      commonDir: null,
      objectsDirs: [],
      logsDirs: [],
      indexFiles: [],
      readOnlyControlPaths: []
    };
  }

  const st = fs.lstatSync(dotGit);
  let gitDir: string | null = null;
  let commonDir: string | null = null;
  let isLinkedWorktree = false;

  if (st.isDirectory()) {
    gitDir = fs.realpathSync(dotGit);
    commonDir = gitDir;
  } else if (st.isFile()) {
    const content = fs.readFileSync(dotGit, "utf8").trim();
    const m = content.match(/^gitdir:\s*(.+)$/);
    if (m) {
      const resolvedGitDir = path.resolve(workspaceRoot, m[1].trim());
      if (fs.existsSync(resolvedGitDir)) {
        gitDir = fs.realpathSync(resolvedGitDir);
        isLinkedWorktree = true;
        const commonDirFile = path.join(gitDir, "commondir");
        if (fs.existsSync(commonDirFile)) {
          const relCommon = fs.readFileSync(commonDirFile, "utf8").trim();
          const candCommon = path.resolve(gitDir, relCommon);
          commonDir = fs.existsSync(candCommon) ? fs.realpathSync(candCommon) : gitDir;
        } else {
          commonDir = path.resolve(gitDir, "../..");
        }
      }
    }
  }

  if (!gitDir || !commonDir) {
    return {
      isGitRepo: false,
      isLinkedWorktree: false,
      gitDir: null,
      commonDir: null,
      objectsDirs: [],
      logsDirs: [],
      indexFiles: [],
      readOnlyControlPaths: []
    };
  }

  const objectsSet = new Set<string>();
  const primaryObjects = path.join(commonDir, "objects");
  if (fs.existsSync(primaryObjects)) {
    objectsSet.add(fs.realpathSync(primaryObjects));
    const altFile = path.join(primaryObjects, "info", "alternates");
    if (fs.existsSync(altFile)) {
      const lines = fs.readFileSync(altFile, "utf8").split(/\r?\n/);
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith("#")) continue;
        const resolvedAlt = path.resolve(primaryObjects, trimmed);
        if (fs.existsSync(resolvedAlt)) {
          objectsSet.add(fs.realpathSync(resolvedAlt));
        }
      }
    }
  }

  const logsSet = new Set<string>();
  for (const d of [path.join(gitDir, "logs"), path.join(commonDir, "logs")]) {
    if (fs.existsSync(d)) logsSet.add(fs.realpathSync(d));
  }

  const indexFiles: string[] = [];
  const idxPath = path.join(gitDir, "index");
  if (fs.existsSync(idxPath) && fs.lstatSync(idxPath).isFile()) {
    indexFiles.push(idxPath);
  }

  const roSet = new Set<string>();
  for (const p of [
    path.join(commonDir, "hooks"),
    path.join(commonDir, "config"),
    path.join(gitDir, "hooks"),
    path.join(gitDir, "config"),
    path.join(gitDir, "config.worktree")
  ]) {
    if (fs.existsSync(p)) roSet.add(p);
  }

  return {
    isGitRepo: true,
    isLinkedWorktree,
    gitDir,
    commonDir,
    objectsDirs: Array.from(objectsSet),
    logsDirs: Array.from(logsSet),
    indexFiles,
    readOnlyControlPaths: Array.from(roSet)
  };
}

export function collectMaskedSecretFiles(
  workspaceRoot: string,
  unmaskedExceptions: readonly string[] = DEFAULT_UNMASKED_SECRET_EXCEPTIONS
): string[] {
  return scanWorkspaceSecretsAndHardlinks(workspaceRoot, unmaskedExceptions).allMaskedPaths;
}

export function buildMinimalBwrapArgv(
  command: string,
  cwd: string,
  cfg: BwrapSandboxConfig
): string[] {
  const ws = fs.realpathSync(cfg.workspaceRoot);
  const effectiveCwd = fs.existsSync(cwd) ? fs.realpathSync(cwd) : ws;
  const mode = cfg.mode ?? "workspace-write";

  if (mode === "danger-full-access") {
    return ["/bin/bash", "-c", command];
  }

  const args: string[] = [
    "--ro-bind", "/usr", "/usr",
    "--ro-bind", "/bin", "/bin",
    "--ro-bind-try", "/sbin", "/sbin",
    "--ro-bind", "/lib", "/lib",
    "--ro-bind-try", "/lib64", "/lib64",
    "--ro-bind-try", "/etc/alternatives", "/etc/alternatives",
    "--ro-bind-try", "/etc/ld.so.cache", "/etc/ld.so.cache",
    "--ro-bind-try", "/etc/ssl/certs", "/etc/ssl/certs",
    "--ro-bind-try", "/etc/ca-certificates", "/etc/ca-certificates",
    "--proc", "/proc",
    "--dev", "/dev",
    "--tmpfs", "/tmp",
    "--tmpfs", "/run",
    "--tmpfs", "/home",
    "--dir", "/home/sandbox"
  ];

  if (mode === "read-only") {
    args.push("--ro-bind", ws, ws);
  } else {
    args.push("--bind", ws, ws);
  }

  for (const extraRo of cfg.extraReadOnlyPaths ?? []) {
    if (fs.existsSync(extraRo)) args.push("--ro-bind", extraRo, extraRo);
  }
  if (mode === "workspace-write") {
    for (const extraRw of cfg.extraWritablePaths ?? []) {
      if (fs.existsSync(extraRw)) args.push("--bind", extraRw, extraRw);
    }
  }

  const gitLayout = resolveGitRepositoryLayout(ws);
  const gitIsoMode = cfg.isolateGitObjectsMode ?? "always";

  // Linked worktree external metadata mounts (commonDir & gitDir live outside `<ws>`)
  if (gitLayout.isLinkedWorktree && gitLayout.commonDir && gitLayout.gitDir) {
    args.push("--ro-bind", gitLayout.commonDir, gitLayout.commonDir);
    if (mode === "workspace-write") {
      args.push("--bind", gitLayout.gitDir, gitLayout.gitDir);
      if (gitIsoMode === "expose-unsafe") {
        for (const objDir of gitLayout.objectsDirs) {
          args.push("--bind", objDir, objDir);
        }
      }
    }
  }

  // Protect control-plane subpaths (`hooks`, `config`, `.harness`) strictly Read-Only
  const absHarness = path.join(ws, ".harness");
  if (fs.existsSync(absHarness)) {
    args.push("--ro-bind", absHarness, absHarness);
  }
  for (const roControl of gitLayout.readOnlyControlPaths) {
    args.push("--ro-bind", roControl, roControl);
  }

  // Isolate Git object & reflog directories (`--tmpfs`) — safe default `"always"` covers reachable,
  // reflog-only, AND unreachable/dangling secret blobs across standard repos and linked worktrees!
  if (gitLayout.isGitRepo && gitIsoMode !== "expose-unsafe") {
    const shouldIsolate =
      gitIsoMode === "always"
        ? { isolateObjects: true, maskIndex: false }
        : (() => {
            const audit = auditGitHistoryForSecretPaths(ws, cfg.unmaskedSecretExceptions);
            return { isolateObjects: audit.hasHistoricalSecrets, maskIndex: audit.hasStagedSecrets };
          })();

    if (shouldIsolate.isolateObjects) {
      for (const objDir of gitLayout.objectsDirs) {
        args.push("--tmpfs", objDir);
      }
      for (const logDir of gitLayout.logsDirs) {
        args.push("--tmpfs", logDir);
      }
    }
    if (shouldIsolate.maskIndex) {
      for (const idxFile of gitLayout.indexFiles) {
        args.push("--ro-bind", "/dev/null", idxFile);
      }
    }
  }

  // Mask workspace secret files & hardlink aliases recursively
  for (const secretPath of collectMaskedSecretFiles(ws, cfg.unmaskedSecretExceptions)) {
    args.push("--ro-bind", "/dev/null", secretPath);
  }

  if (cfg.unshareNet !== false) {
    args.push("--unshare-net");
  }

  args.push(
    "--unshare-pid",
    "--die-with-parent",
    "--new-session",
    "--clearenv",
    "--setenv", "PATH", "/usr/local/bin:/usr/bin:/bin",
    "--setenv", "HOME", "/home/sandbox",
    "--setenv", "TMPDIR", "/tmp",
    "--setenv", "LANG", "C.UTF-8",
    "--setenv", "TERM", "dumb",
    "--chdir", effectiveCwd,
    "--",
    "/bin/bash",
    "-c",
    command
  );

  return args;
}

export function createBwrapBashOperations(cfg: BwrapSandboxConfig): BashOperations {
  return {
    exec: async (command, cwd, options) => {
      const mode = cfg.mode ?? "workspace-write";
      let bin = "bwrap";
      let argv: string[];

      if (mode === "danger-full-access") {
        bin = "/bin/bash";
        argv = ["-c", command];
      } else {
        const probe = probeBwrapFunctional();
        if (!probe.ok) {
          if (!cfg.allowUnsandboxedDev) {
            throw new SandboxUnavailableError(
              `SANDBOX_UNAVAILABLE: bubblewrap confinement failed (${probe.reason ?? "unknown"}). Refusing unconfined execution.`
            );
          }
          bin = "/bin/bash";
          argv = ["-c", command];
        } else {
          argv = buildMinimalBwrapArgv(command, cwd, cfg);
        }
      }

      return await new Promise<{ exitCode: number | null }>((resolve, reject) => {
        const child = spawn(bin, argv, {
          cwd: fs.existsSync(cwd) ? cwd : cfg.workspaceRoot,
          env: {},
          stdio: ["ignore", "pipe", "pipe"]
        });

        let timedOut = false;
        let timer: NodeJS.Timeout | undefined;
        if (options.timeout && options.timeout > 0) {
          timer = setTimeout(() => {
            timedOut = true;
            child.kill("SIGKILL");
          }, options.timeout * 1000);
        }

        const onAbort = () => {
          child.kill("SIGKILL");
        };
        if (options.signal) {
          if (options.signal.aborted) {
            child.kill("SIGKILL");
          } else {
            options.signal.addEventListener("abort", onAbort, { once: true });
          }
        }

        child.stdout.on("data", (chunk: Buffer) => options.onData(chunk));
        child.stderr.on("data", (chunk: Buffer) => options.onData(chunk));
        child.on("error", (err) => {
          if (timer) clearTimeout(timer);
          options.signal?.removeEventListener("abort", onAbort);
          reject(err);
        });
        child.on("close", (code, signal) => {
          if (timer) clearTimeout(timer);
          options.signal?.removeEventListener("abort", onAbort);
          if (timedOut) {
            options.onData(Buffer.from("\n[sandbox: command timed out]\n", "utf8"));
            resolve({ exitCode: 124 });
            return;
          }
          if (signal) {
            resolve({ exitCode: 128 + 9 });
            return;
          }
          resolve({ exitCode: code });
        });
      });
    }
  };
}
