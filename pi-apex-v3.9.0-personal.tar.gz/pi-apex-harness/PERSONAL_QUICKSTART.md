# Pi-Apex `v3.9.0` — Personal Linux Workstation Quickstart Guide

Welcome to **Pi-Apex (`v3.9.0`, Rings 0–9 Omni-Channel, Swarm, Plugin & Self-Learning Ledger Edition)** — your confined, self-evolving personal coding harness built atop `@earendil-works/pi-coding-agent@1.4.0`, `@earendil-works/pi-codemode@1.4.0`, `@earendil-works/pi-mcp@1.4.0`, and `@earendil-works/pi-tui@1.4.0`.

## 1. Host Prerequisites (Personal Linux `x86_64` / `arm64`)

- **Linux Kernel `>= 5.6`** (for native `openat2(RESOLVE_BENEATH | RESOLVE_NO_SYMLINKS)` path-confinement syscall broker)
- **Node.js `>= 22.19.0`** (uses built-in `node:sqlite` WAL + FTS5, built-in `WebSocket` for Chromium CDP, and native `.ts` type-stripping)
- **`gcc`** + standard C headers (`build-essential`), **`git >= 2.38`**, **`bubblewrap` (`bwrap >= 0.8`)**, and **`chromium` + `xvfb`** (for live Headless Chromium CDP `@e1` ARIA snapshots & screenshots)

```bash
# Debian / Ubuntu / Pop!_OS:
sudo apt-get update && sudo apt-get install -y build-essential git bubblewrap chromium xvfb
```

## 2. Unpack, Install (CLI + systemd + VS Code / Cursor) & Verify in 60 Seconds

```bash
tar -xzf pi-apex-v3.9.0-personal.tar.gz
cd pi-apex-harness

# Install dependencies, compile native Linux openat2 C broker, and run all 61 checks (Rings 0–9):
npm install
npm test

# Run the 3-repo SWE Eval & Harness² EXPERIENCE.md A/B Prompt-Cache Benchmark:
npm run bench

# Install ~/.local/bin/pi-apex + systemd --user Cockpit service + VS Code & Cursor RPC extension:
bash scripts/install-personal.sh --install-systemd-user --install-vscode
```

## 3. Daily-Driver Commands (21 Zero-Token Slash Commands)

| Command | Purpose |
|---|---|
| `pi-apex --cwd ~/my-repo` | Launch interactive terminal TUI (`Ctrl+Alt+P` toggles Plan Mode) |
| `pi-apex --cwd ~/my-repo --web --port 4310` | Launch 9-Tab Mission-Control Web Cockpit (`http://127.0.0.1:4310`) |
| `/gateway pair <platform>` | Issue a 1-time 6-digit pairing code for `telegram`, `discord`, `slack`, `signal`, `whatsapp_baileys`, or `whatsapp_cloud` |
| `/gateway whatsapp [+316...]` | Initialize personal WhatsApp Baileys QR / 8-char multi-device link code |
| `/gateway slack-manifest` | Export native Slack App Manifest mapping all 21 Pi-Apex slash commands |
| `/send <platform> <channelId> <msg>` | Send a zero-LLM notification (`hermes send` port) |
| `/agents` & `/swarm debate <goal>` | Inspect `.agents/agents/*.md` personas or run `dag` / `supervisor` / `debate` / `map_reduce` multi-agent orchestration |
| `/plugin audit\|install <dir>` | Quarantine-scan (`skills-guard-v10` + capability check) & hot-load external `apex-plugin.json` plugins (`+0` schema bloat) |
| `/ledger verify\|list\|materialize` | Verify SHA-256 hash chain on `.harness/ledger/SELF_LEARNING_LEDGER.jsonl` & materialize next-boot `EXPERIENCE.md` |
| `/pr --auto <issueUrl\|#42>` | Quarantine-scan GitHub Issue & run autonomous self-healing Issue-to-PR pipeline |
| `/bench` | Run 3-repo SWE Eval & `o200k_base` Prompt-Cache Benchmark Suite |
| `/doctor` | Verify all 9 health & confinement invariants (`schema=1073`, `0` drift) |
