/**
 * Ring 3 — Final Self-Evolution, Skill Curation, Memory Dreaming & Computer-Use Extension Pack.
 *
 * Composes `Ring 0 + Ring 1 + Ring 2 + Ring 3` while preserving ALL locked architectural invariants:
 *  - `1,073 === 1,073` `o200k_base` active tool schema tokens (`exposure: "deferred"` across all
 *    12 specialist tools from Ring 1, Ring 2, and Ring 3 + QuickJS `Codemode`).
 *  - `<= 2,100` `o200k_base` boot-pinned static prefix with `0` mid-session SHA-256 drift.
 *  - Cryptographically pinned `surfaces-immutable/GUARDRAILS.yaml` (`0444`, SHA-256 verified)
 *    mechanically untouchable by `Harness²` `Propose–Probe–Compose` (`Harness²` Issue #94 fix).
 *  - Quarantine-first Hermes skill distillation (`.skills-quarantine/` + `skills-guard-v10` +
 *    operator approval gate + `#11227` symlink refusal + `#29912` umbrella consolidation guard).
 *  - `Dreaming` offline episodic memory consolidation (`episodes_fts` -> Hermes `#115104`
 *    two-pass learned-token scrubbing -> `<= 300`-token `surfaces/MEMORY.md` staged for next boot).
 *  - Optional gated `cua_control` desktop GUI controller (disabled by default, viewport-bounded,
 *    approval-gated, RFC-2083 PNG `ImageContent` screenshots).
 */

import path from "node:path";
import type { ImageContent, TextContent } from "@earendil-works/pi-ai";
import type { ExtensionFactory } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { loadVerifiedGuardrails } from "../core/guardrail-pin.ts";
import type { Ring0HarnessOptions } from "../core/ring0-session.ts";
import type { Ring1Options } from "../ring1/ring1-extension.ts";
import {
  createRing2Harness,
  type Ring2HarnessInstance,
  type Ring2Options
} from "../ring2/ring2-extension.ts";
import {
  CuaComputerDriver,
  type CuaActionKind,
  type CuaActionRequest,
  type CuaViewport
} from "./cua-computer-driver.ts";
import { DreamingMemoryConsolidator } from "./dreaming-consolidator.ts";
import {
  Harness2ContrastiveEvolver,
  type CandidateRollout
} from "./harness2-contrastive-evolver.ts";
import {
  QuarantinedSkillCurator,
  type SkillLifecycleStatus,
  type SkillTrustLevel
} from "./skills-guard-quarantine.ts";

export interface Ring3Options {
  maxExperienceTokens?: number;
  enableCua?: boolean;
  cuaViewport?: CuaViewport;
  cuaApprovalCallback?: (req: CuaActionRequest) => Promise<boolean> | boolean;
}

export interface Ring3HarnessInstance extends Ring2HarnessInstance {
  readonly skillCurator: QuarantinedSkillCurator;
  readonly experienceEvolver: Harness2ContrastiveEvolver;
  readonly dreamingConsolidator: DreamingMemoryConsolidator;
  readonly cuaDriver: CuaComputerDriver;
}

export async function createRing3Harness(
  opts: Ring0HarnessOptions & {
    ring1?: Ring1Options;
    ring2?: Ring2Options;
    ring3?: Ring3Options;
  }
): Promise<Ring3HarnessInstance> {
  const { config: guardrails } = loadVerifiedGuardrails(
    opts.guardrailsPath,
    opts.expectedGuardrailsSha256
  );

  let skillCuratorRef: QuarantinedSkillCurator | null = null;
  let experienceEvolverRef: Harness2ContrastiveEvolver | null = null;
  let dreamingConsolidatorRef: DreamingMemoryConsolidator | null = null;

  const cuaDriver = new CuaComputerDriver({
    enabled: opts.ring3?.enableCua ?? false,
    viewport: opts.ring3?.cuaViewport,
    approvalCallback: opts.ring3?.cuaApprovalCallback
  });

  const CandidateRolloutSchema = Type.Object({
    label: Type.String(),
    proposedTargetSurface: Type.String(),
    proposedExperience: Type.Object({
      cue: Type.String(),
      lesson: Type.String(),
      evidence: Type.String(),
      confidence: Type.Optional(Type.String()),
      edits: Type.Optional(Type.String())
    }),
    answerText: Type.String(),
    probeScore: Type.Number(),
    probeRegressions: Type.Number()
  });

  const ring3Extension: ExtensionFactory = (pi) => {
    // 1. `skill_curator` (`exposure: "deferred"` -> +0 active schema tokens)
    pi.registerTool({
      name: "skill_curator",
      label: "Quarantined Skill Distiller & Curator",
      description:
        "Distills skills into .skills-quarantine/ with skills-guard-v10 static scanning, promotes operator-approved skills, consolidates into umbrella skills, and runs stale/archive lifecycle passes.",
      parameters: Type.Object({
        action: Type.Union([
          Type.Literal("distill"),
          Type.Literal("promote"),
          Type.Literal("inspect"),
          Type.Literal("consolidate"),
          Type.Literal("lifecycle_pass"),
          Type.Literal("list")
        ]),
        name: Type.Optional(Type.String()),
        skillMd: Type.Optional(Type.String()),
        supportingFiles: Type.Optional(Type.Record(Type.String(), Type.String())),
        trustLevel: Type.Optional(
          Type.Union([
            Type.Literal("builtin"),
            Type.Literal("trusted"),
            Type.Literal("community"),
            Type.Literal("agent-created")
          ])
        ),
        operatorApproved: Type.Optional(Type.Boolean()),
        recordUse: Type.Optional(Type.Boolean()),
        absorbedInto: Type.Optional(Type.String()),
        statusFilter: Type.Optional(
          Type.Union([
            Type.Literal("quarantined"),
            Type.Literal("active"),
            Type.Literal("stale"),
            Type.Literal("archived")
          ])
        ),
        staleAfterDays: Type.Optional(Type.Number()),
        archiveAfterDays: Type.Optional(Type.Number())
      }),
      exposure: "deferred",
      async execute(_id, params): Promise<{ content: TextContent[]; details: unknown }> {
        if (!skillCuratorRef) throw new Error("QuarantinedSkillCurator not initialized");
        switch (params.action) {
          case "distill": {
            const res = skillCuratorRef.distillToQuarantine({
              skillMd: params.skillMd ?? "",
              supportingFiles: params.supportingFiles,
              trustLevel: params.trustLevel as SkillTrustLevel | undefined
            });
            return {
              content: [
                {
                  type: "text",
                  text: `Quarantined '${res.record.name}' at ${res.quarantinedPath} (verdict=${res.scan.verdict}, findings=${res.scan.findings.length}).`
                }
              ],
              details: res
            };
          }
          case "promote": {
            const res = skillCuratorRef.promoteFromQuarantine({
              name: params.name ?? "",
              operatorApproved: Boolean(params.operatorApproved)
            });
            return {
              content: [
                {
                  type: "text",
                  text: `Promoted '${res.record.name}' -> ${res.promotedPath} (status=${res.record.status}).`
                }
              ],
              details: res
            };
          }
          case "inspect": {
            const body = skillCuratorRef.inspectOrRecordUse(params.name ?? "", {
              recordUse: params.recordUse
            });
            return {
              content: [{ type: "text", text: body }],
              details: skillCuratorRef.getSkillRecord(params.name ?? "")
            };
          }
          case "consolidate": {
            const rec = skillCuratorRef.consolidateIntoUmbrella({
              name: params.name ?? "",
              absorbedInto: params.absorbedInto ?? ""
            });
            return {
              content: [
                {
                  type: "text",
                  text: `Archived '${rec.name}' into .agents/.archive/ (absorbedInto='${rec.absorbedInto}').`
                }
              ],
              details: rec
            };
          }
          case "lifecycle_pass": {
            const summary = skillCuratorRef.runAutomaticLifecyclePass({
              staleAfterDays: params.staleAfterDays,
              archiveAfterDays: params.archiveAfterDays
            });
            return {
              content: [
                {
                  type: "text",
                  text: `Lifecycle pass: markedStale=[${summary.markedStale.join(",")}], archived=[${summary.archived.join(",")}], skippedProtected=[${summary.skippedProtected.join(",")}].`
                }
              ],
              details: summary
            };
          }
          case "list": {
            const list = skillCuratorRef.listSkills(
              params.statusFilter as SkillLifecycleStatus | undefined
            );
            return {
              content: [
                {
                  type: "text",
                  text:
                    list.length === 0
                      ? "(no skills tracked)"
                      : list
                          .map(
                            (s) =>
                              `- ${s.name} [${s.status}] uses=${s.useCount} verdict=${s.lastScanVerdict}`
                          )
                          .join("\n")
                }
              ],
              details: list
            };
          }
        }
      }
    });

    // 2. `experience_evolver` (`exposure: "deferred"` -> +0 active schema tokens)
    pi.registerTool({
      name: "experience_evolver",
      label: "Harness² Contrastive Experience Evolver",
      description:
        "Runs offline Harness² contrastive Propose-Probe-Compose strictly confined to surfaces/EXPERIENCE.md behind 4 validation gates, or recalls domain cues/lessons.",
      parameters: Type.Object({
        action: Type.Union([
          Type.Literal("evolve"),
          Type.Literal("recall"),
          Type.Literal("read_surface")
        ]),
        domain: Type.Optional(Type.String()),
        taskId: Type.Optional(Type.String()),
        baseline: Type.Optional(CandidateRolloutSchema),
        candidates: Type.Optional(Type.Array(CandidateRolloutSchema)),
        selectorReplyText: Type.Optional(Type.String()),
        query: Type.Optional(Type.String()),
        limit: Type.Optional(Type.Number())
      }),
      exposure: "deferred",
      async execute(_id, params): Promise<{ content: TextContent[]; details: unknown }> {
        if (!experienceEvolverRef) throw new Error("Harness2ContrastiveEvolver not initialized");
        switch (params.action) {
          case "evolve": {
            if (!params.baseline) {
              throw new Error("'evolve' requires a baseline rollout.");
            }
            const res = experienceEvolverRef.runProposeProbeCompose({
              domain: params.domain ?? "general",
              taskId: params.taskId ?? "task",
              baseline: params.baseline as CandidateRollout,
              candidates: (params.candidates ?? []) as CandidateRollout[],
              selectorReplyText: params.selectorReplyText
            });
            return {
              content: [
                {
                  type: "text",
                  text: `Harness² Compose adopted=${res.adopted} chosen=${res.chosenLabel} (${res.experienceMdTokens} o200k tokens).`
                }
              ],
              details: res
            };
          }
          case "recall": {
            const hits = experienceEvolverRef.recallRelevantExperiences({
              domain: params.domain ?? "general",
              query: params.query,
              limit: params.limit
            });
            return {
              content: [
                {
                  type: "text",
                  text:
                    hits.length === 0
                      ? "(no matching domain experiences)"
                      : hits
                          .map(
                            (h) =>
                              `- [${h.slug}] cue: ${h.experience.cue} => lesson: ${h.experience.lesson} (evidence: ${h.experience.evidence})`
                          )
                          .join("\n")
                }
              ],
              details: hits
            };
          }
          case "read_surface": {
            const md = experienceEvolverRef.readCurrentExperienceMd();
            return {
              content: [{ type: "text", text: md }],
              details: { markdown: md }
            };
          }
        }
      }
    });

    // 3. `dream_memory` (`exposure: "deferred"` -> +0 active schema tokens)
    pi.registerTool({
      name: "dream_memory",
      label: "Dreaming Episodic Memory Consolidator",
      description:
        "Consolidates FTS5 episodic logs into secret-scrubbed, <=300-token surfaces/MEMORY.md staged for next session boot without mutating live static prefix.",
      parameters: Type.Object({
        query: Type.Optional(Type.String()),
        limitEpisodes: Type.Optional(Type.Number()),
        preserveHeaderBullets: Type.Optional(Type.Boolean())
      }),
      exposure: "deferred",
      async execute(_id, params): Promise<{ content: TextContent[]; details: unknown }> {
        if (!dreamingConsolidatorRef) throw new Error("DreamingMemoryConsolidator not initialized");
        const res = dreamingConsolidatorRef.runDreamingPass({
          query: params.query,
          limitEpisodes: params.limitEpisodes,
          preserveHeaderBullets: params.preserveHeaderBullets
        });
        return {
          content: [
            {
              type: "text",
              text: `Dreaming consolidated ${res.bulletsRetained} bullet(s) into ${res.memoryMdPath} (${res.memoryMdTokens}/${res.maxMemoryTokens} o200k tokens; rejectedPoisoned=${res.rejectedPoisonedEpisodes}; appliesOnNextSessionBoot=${res.appliesOnNextSessionBoot}).`
            }
          ],
          details: res
        };
      }
    });

    // 4. `cua_control` (`exposure: "deferred"` -> +0 active schema tokens)
    pi.registerTool({
      name: "cua_control",
      label: "Gated Desktop Computer-Use Driver",
      description:
        "Optional viewport-bounded, operator-approval-gated GUI computer-use controller returning multimodal PNG screenshots.",
      parameters: Type.Object({
        action: Type.Union([
          Type.Literal("screenshot"),
          Type.Literal("cursor_position"),
          Type.Literal("move"),
          Type.Literal("click"),
          Type.Literal("double_click"),
          Type.Literal("scroll"),
          Type.Literal("type"),
          Type.Literal("key"),
          Type.Literal("drag")
        ]),
        x: Type.Optional(Type.Number()),
        y: Type.Optional(Type.Number()),
        toX: Type.Optional(Type.Number()),
        toY: Type.Optional(Type.Number()),
        scrollDeltaY: Type.Optional(Type.Number()),
        text: Type.Optional(Type.String()),
        keyChord: Type.Optional(Type.String()),
        operatorApproved: Type.Optional(Type.Boolean())
      }),
      exposure: "deferred",
      async execute(
        _id,
        params
      ): Promise<{ content: Array<TextContent | ImageContent>; details: unknown }> {
        const receipt = await cuaDriver.dispatch({
          action: params.action as CuaActionKind,
          x: params.x,
          y: params.y,
          toX: params.toX,
          toY: params.toY,
          scrollDeltaY: params.scrollDeltaY,
          text: params.text,
          keyChord: params.keyChord,
          operatorApproved: params.operatorApproved
        });
        const content: Array<TextContent | ImageContent> = [
          { type: "text", text: receipt.auditSummary }
        ];
        if (receipt.screenshotPngBase64) {
          content.push({
            type: "image",
            mimeType: "image/png",
            data: receipt.screenshotPngBase64
          });
        }
        return { content, details: receipt };
      }
    });
  };

  const ring2 = await createRing2Harness({
    ...opts,
    extraExtensions: [ring3Extension, ...(opts.extraExtensions ?? [])]
  });

  const resolvedSurfacesDir =
    opts.surfacesDir ?? path.join(path.resolve(opts.workspaceRoot), "surfaces");

  const skillCurator = new QuarantinedSkillCurator({
    db: ring2.stateDb.db,
    workspaceRoot: opts.workspaceRoot,
    durabilityMode: opts.durabilityMode ?? "crash-safe"
  });

  const experienceEvolver = new Harness2ContrastiveEvolver({
    workspaceRoot: opts.workspaceRoot,
    surfacesDir: resolvedSurfacesDir,
    db: ring2.stateDb.db,
    guardrailsPath: opts.guardrailsPath,
    expectedGuardrailsSha256: opts.expectedGuardrailsSha256,
    durabilityMode: opts.durabilityMode ?? "crash-safe",
    maxExperienceTokens: opts.ring3?.maxExperienceTokens
  });

  const dreamingConsolidator = new DreamingMemoryConsolidator({
    stateDb: ring2.stateDb,
    workspaceRoot: opts.workspaceRoot,
    surfacesDir: resolvedSurfacesDir,
    guardrails,
    durabilityMode: opts.durabilityMode ?? "crash-safe"
  });

  skillCuratorRef = skillCurator;
  experienceEvolverRef = experienceEvolver;
  dreamingConsolidatorRef = dreamingConsolidator;

  return {
    ...ring2,
    skillCurator,
    experienceEvolver,
    dreamingConsolidator,
    cuaDriver
  };
}
