/** Ring 11 — Session-local confirmation modes; never overrides immutable sandbox/guardrail boundaries. */
import crypto from "node:crypto";

export type ExecutionMode = "review" | "default" | "auto" | "turbo";
export type ActionDecision = "allow" | "confirm" | "deny";
export interface PendingApproval {
  approvalId: string;
  tool: string;
  summary: string;
  classification: ActionDecision;
  rationale: string;
  createdAtMs: number;
}

const SENSITIVE = /\b(rm|mv|cp|chmod|chown|git\s+(?:push|commit|reset|checkout|clean)|npm\s+(?:install|publish)|pnpm\s+(?:add|install)|pip\s+install|curl|wget|ssh|sudo|systemctl|docker|podman)\b|(?:>|>>|\|\s*sh)|\.(?:env|pem|key)\b/i;
const HARD_DENY = /(?:rm\s+-rf\s+\/(?:\s|$)|mkfs(?:\.|\s)|dd\s+if=.*of=\/dev\/(?:sd|nvme)|curl\s+[^\n]*169\.254\.169\.254|\/dev\/(?:tcp|udp)\/)/i;
const SAFE_READ = /^(?:pwd|ls|find|cat|head|tail|grep|rg|git\s+(?:status|diff|log|show)|npm\s+test|npm\s+run\s+(?:typecheck|lint|test)|node\s+--version|which|file|stat)(?:\s|$)/i;

export class ExecutionModeController {
  private mode: ExecutionMode = "default";
  private persona = "general";
  private buildProfile = "custom";
  private pending = new Map<string, { approval: PendingApproval; resolve: (allow: boolean) => void }>();
  private recent: Array<PendingApproval & { outcome: "approved" | "denied" | "auto-allowed" | "blocked" }> = [];
  private consumerAttached = false;
  private onChange?: (event: { type: string; approval?: PendingApproval }) => void;
  constructor(opts?: { onChange?: (event: { type: string; approval?: PendingApproval }) => void }) {
    this.onChange = opts?.onChange;
  }
  getMode(): ExecutionMode { return this.mode; }
  setObserver(observer?: (event: { type: string; approval?: PendingApproval }) => void): void { this.onChange = observer; }
  getInteractionState(): { mode: ExecutionMode; persona: string; buildProfile: string; pending: PendingApproval[]; recent: Array<PendingApproval & { outcome: "approved" | "denied" | "auto-allowed" | "blocked" }> } {
    return { mode: this.mode, persona: this.persona, buildProfile: this.buildProfile, pending: this.listPending(), recent: this.listRecent() };
  }
  setPersonaProfile(persona?: string, buildProfile?: string): { persona: string; buildProfile: string } {
    const personas = ["general", "architect", "builder", "reviewer", "pair-programmer"];
    const profiles = ["implement", "plan", "review", "fast-local", "custom"];
    if (persona && !personas.includes(persona)) throw new Error("CHAT_PERSONA_UNSUPPORTED");
    if (buildProfile && !profiles.includes(buildProfile)) throw new Error("BUILD_PROFILE_UNSUPPORTED");
    if (persona) this.persona = persona;
    if (buildProfile) this.buildProfile = buildProfile;
    this.onChange?.({ type: "interaction_profile_changed" });
    return { persona: this.persona, buildProfile: this.buildProfile };
  }
  getPersonaContext(): string {
    const profiles: Record<string, string> = {
      general: "Help the operator directly and adapt to the task.",
      architect: "Act as a software architect: clarify constraints, map interfaces, and propose a staged plan before implementation.",
      builder: "Act as a pragmatic implementation engineer: make focused changes and run relevant checks.",
      reviewer: "Act as a security-minded reviewer: prioritize correctness, regressions, trust boundaries, and concrete findings.",
      "pair-programmer": "Act as a collaborative pair programmer: explain tradeoffs briefly and ask before making broad changes."
    };
    return profiles[this.persona] ?? profiles.general!;
  }
  setMode(mode: ExecutionMode): ExecutionMode {
    if (!["review", "default", "auto", "turbo"].includes(mode)) throw new Error("INTERACTION_MODE_INVALID");
    this.mode = mode;
    this.onChange?.({ type: "execution_mode_changed" });
    return mode;
  }
  setApprovalConsumerAttached(attached: boolean): void { this.consumerAttached = attached; }
  listPending(): PendingApproval[] { return [...this.pending.values()].map((p) => p.approval); }
  listRecent(): Array<PendingApproval & { outcome: "approved" | "denied" | "auto-allowed" | "blocked" }> { return this.recent.slice(-30); }
  resolveApproval(id: string, allow: boolean): boolean {
    const item = this.pending.get(id);
    if (!item) return false;
    this.pending.delete(id);
    this.record({ ...item.approval, outcome: allow ? "approved" : "denied" });
    item.resolve(allow);
    this.onChange?.({ type: "approval_resolved" });
    return true;
  }
  async beforeAction(tool: string, summary: string): Promise<void> {
    const mode = this.mode;
    const sensitive = SENSITIVE.test(summary) || ["write", "edit", "delete", "plugin", "gateway_send"].includes(tool);
    const hardDenied = HARD_DENY.test(summary);
    if (hardDenied) {
      this.record({ approvalId: `deny_${crypto.randomUUID()}`, tool, summary, classification: "deny", rationale: "Hard-deny rule; execution mode cannot override it.", createdAtMs: Date.now(), outcome: "blocked" });
      throw new Error("EXECUTION_HARD_DENY: action violates a non-overridable safety rule.");
    }
    if (mode === "turbo") {
      this.record({ approvalId: `auto_${crypto.randomUUID()}`, tool, summary, classification: "allow", rationale: "Turbo skips confirmation only; existing sandbox and guardrails remain active.", createdAtMs: Date.now(), outcome: "auto-allowed" });
      return;
    }
    if (mode === "auto" && !sensitive && SAFE_READ.test(summary)) {
      this.record({ approvalId: `auto_${crypto.randomUUID()}`, tool, summary, classification: "allow", rationale: "Deterministic read-only command allowlist.", createdAtMs: Date.now(), outcome: "auto-allowed" });
      return;
    }
    const requireApproval = mode === "review" || sensitive || (mode === "auto" && !SAFE_READ.test(summary));
    if (!requireApproval) return;
    if (!this.consumerAttached) throw new Error("APPROVAL_REQUIRED_BUT_NO_OPERATOR_UI: start the Cockpit or choose an explicitly configured noninteractive policy.");
    const approval: PendingApproval = {
      approvalId: `apr_${crypto.randomBytes(8).toString("hex")}`,
      tool,
      summary: summary.slice(0, 2_000),
      classification: "confirm",
      rationale: mode === "review" ? "Review mode requires approval for every command." : "Action is sensitive or outside the deterministic read-only allowlist.",
      createdAtMs: Date.now()
    };
    const allowed = await new Promise<boolean>((resolve) => {
      this.pending.set(approval.approvalId, { approval, resolve });
      this.onChange?.({ type: "approval_requested", approval });
      const timer = setTimeout(() => {
        if (this.pending.has(approval.approvalId)) this.resolveApproval(approval.approvalId, false);
      }, 120_000);
      timer.unref?.();
    });
    if (!allowed) throw new Error("OPERATOR_DENIED_OR_APPROVAL_TIMED_OUT: action was not executed.");
  }
  private record(item: PendingApproval & { outcome: "approved" | "denied" | "auto-allowed" | "blocked" }): void {
    this.recent.push(item);
    if (this.recent.length > 100) this.recent.splice(0, this.recent.length - 100);
  }
}
