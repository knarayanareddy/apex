# API

## `quantum_walkers.hadamard`

- `SHOTS: int` — default shots.
- `one_hadamard() -> QuantumCircuit` — |0⟩ —H— M
- `two_hadamards() -> QuantumCircuit` — |0⟩ —H—H— M
- `run(qc, shots=SHOTS, seed=None, optimization_level=0) -> dict[str,int]`

## `quantum_walkers.walk`

- `POSITION_QUBITS`, `START`, `COIN_STATES`
- `increment(n) -> QuantumCircuit`
- `coined_walk(steps, n=POSITION_QUBITS, start=START, coin_state="symmetric", measure=True) -> QuantumCircuit`
- `exact_distribution(steps, n, start, coin_state) -> np.ndarray`
- `sampled_distribution(steps, shots=1000, seed=None, n, start, coin_state) -> np.ndarray`
- `spread(probs) -> float`
- `plot_comparison(...)`

## `quantum_walkers.classical`

- `classical_distribution(steps, n, start) -> np.ndarray`

## `quantum_walkers.coins`

- `hadamard_coin() -> Operator`
- `grover_coin(dim=2) -> Operator`
- `fourier_coin(dim=2) -> Operator`
- `coin_gate(name, dim=2) -> Gate`

## `quantum_walkers.visualization`

- `plot_comparison(steps=15, shots=1000, path=...)`
- `plot_walk_evolution(steps_list, path, ...)`

## `quantum_walkers.noise`

- `depolarizing_noise_model(p1=0.001, p2=0.01) -> NoiseModel`
- `readout_error_model(p0g1=0.02, p1g0=0.02) -> NoiseModel`
