# Theory — Why the quantum walk spreads faster

## 1. Coined walk on a line

State: `|coin⟩ ⊗ |position⟩`, coin ∈ {|0⟩,|1⟩}, position ∈ {0..2^n-1}.

Initial state: `|coin⟩ = (|0⟩ + i|1⟩)/√2` (symmetric), `|position⟩ = |START⟩`.

One step: `U = S · (H ⊗ I)` where `H` is Hadamard on the coin and `S` is the conditional shift:

```
S |0⟩|x⟩ = |0⟩|x-1⟩
S |1⟩|x⟩ = |1⟩|x+1⟩
```

## 2. Interference

Without measurement between steps, paths to the same position add as amplitudes, not probabilities. Constructive interference at the fronts and destructive in the middle produces the double-peaked distribution, versus the binomial bell curve classically.

## 3. Spread

Classical: variance = t, so σ = √t (diffusive).

Quantum: asymptotically σ ≈ 0.54 t (ballistic). Proven by Nayak & Vishwanath (2000) and Ambainis et al. (2001) via Fourier analysis. Our 5-qubit, 15-step simulation gives σ=8.14 vs classical 3.87 (2.1×).

## 4. Parity

After t steps from START, only positions with `(pos % 2) == (START+t) % 2` are reachable — each step flips parity. Verified by `test_parity_unreachable_zero`.

## 5. Symmetric coin

`H` alone biases the walk. `H·S` (i.e. H then S phase) on |0⟩ gives `(|0⟩+i|1⟩)/√2`, which restores left-right symmetry. Basis states |0⟩/|1⟩ drift left/right respectively.

## References

- Nayak & Vishwanath, *Quantum walk on the line*, arXiv:quant-ph/0002072
- Ambainis et al., *One-dimensional quantum walks*, STOC 2001
- Qiskit Textbook, *Quantum random walk*
