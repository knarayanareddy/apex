"""Tests for quantum walk core (increment, coined_walk, distributions, spread)."""

import numpy as np
import pytest
from qiskit.quantum_info import Operator, Statevector

from quantum_walkers.walk import (
    COIN_STATES,
    POSITION_QUBITS,
    START,
    coined_walk,
    exact_distribution,
    increment,
    sampled_distribution,
    spread,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


def test_position_constants() -> None:
    assert POSITION_QUBITS == 5
    assert START == 16
    assert COIN_STATES == ("symmetric", "zero", "one")


# ---------------------------------------------------------------------------
# increment
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("n", [1, 2, 3, 4, 5, 6])
def test_increment_is_unitary_and_correct(n: int) -> None:
    op = Operator(increment(n)).data
    # Must be permutation: each column has exactly one 1
    for x in range(2**n):
        col = op[:, x]
        # +1 mod 2**n means row (x+1)%2**n is 1
        assert op[(x + 1) % 2**n, x] == pytest.approx(1)
        assert np.count_nonzero(np.abs(col) > 1e-9) == 1
    # Unitary
    assert np.allclose(op @ op.conj().T, np.eye(2**n))


def test_increment_named_plus_one() -> None:
    assert increment(3).name == "+1"


@pytest.mark.parametrize("bad_n", [0, -1, -5])
def test_increment_rejects_bad_n(bad_n: int) -> None:
    with pytest.raises(ValueError, match="n must be >=1"):
        increment(bad_n)


def test_increment_one_qubit_is_x() -> None:
    # +1 mod 2 on 1 qubit is X
    op = Operator(increment(1))
    assert op.equiv(Operator.from_label("X"))


# ---------------------------------------------------------------------------
# coined_walk construction & validation
# ---------------------------------------------------------------------------


def test_zero_steps_stays_at_start() -> None:
    probs = exact_distribution(0)
    assert probs[START] == pytest.approx(1)
    assert probs.sum() == pytest.approx(1)


def test_one_step_is_fifty_fifty_left_right() -> None:
    probs = exact_distribution(1)
    assert probs[START - 1] == pytest.approx(0.5)
    assert probs[START + 1] == pytest.approx(0.5)
    # No other positions populated
    mask = np.ones(2**POSITION_QUBITS, dtype=bool)
    mask[START - 1] = False
    mask[START + 1] = False
    assert probs[mask].sum() == pytest.approx(0)


@pytest.mark.parametrize("steps", [3, 8, 15])
def test_probabilities_sum_to_one_and_respect_parity(steps: int) -> None:
    probs = exact_distribution(steps)
    assert probs.sum() == pytest.approx(1)
    unreachable = np.arange(len(probs)) % 2 != (START + steps) % 2
    assert probs[unreachable].sum() == pytest.approx(0, abs=1e-12)


def test_symmetric_coin_gives_symmetric_distribution() -> None:
    probs = exact_distribution(10)
    d = np.arange(11)
    assert np.allclose(probs[START + d], probs[START - d])


def test_basis_coin_states_drift_in_opposite_directions() -> None:
    x = np.arange(2**POSITION_QUBITS)
    left = exact_distribution(10, coin_state="zero") @ x - START
    right = exact_distribution(10, coin_state="one") @ x - START
    assert left < -1
    assert right == pytest.approx(-left, abs=1e-6)


def test_quantum_walk_spreads_faster_than_classical() -> None:
    from quantum_walkers.classical import classical_distribution

    steps = 15
    assert spread(exact_distribution(steps)) > 2 * spread(classical_distribution(steps))


def test_custom_n_and_start() -> None:
    # 3 position qubits → 8 positions, start=4, 2 steps
    probs = exact_distribution(2, n=3, start=4, coin_state="symmetric")
    assert probs.sum() == pytest.approx(1)
    assert len(probs) == 8
    # Parity: START 4 even + 2 steps even → only even positions reachable
    unreachable = np.arange(8) % 2 != (4 + 2) % 2
    assert probs[unreachable].sum() == pytest.approx(0, abs=1e-12)


def test_measure_flag() -> None:
    qc_true = coined_walk(2, measure=True)
    qc_false = coined_walk(2, measure=False)
    assert qc_true.num_clbits == POSITION_QUBITS
    assert qc_false.num_clbits == 0


def test_walk_is_unitary_before_measurement() -> None:
    qc = coined_walk(3, measure=False)
    # Circuit without measurement should be unitary (isolated system)
    sv = Statevector(qc)
    # Statevector norm ==1 proves unitary preparation from |0>
    assert np.isclose(np.linalg.norm(sv.data), 1)


def test_walk_circuit_depth_grows_with_steps() -> None:
    d0 = coined_walk(0, measure=False).depth()
    d2 = coined_walk(2, measure=False).depth()
    d5 = coined_walk(5, measure=False).depth()
    assert d0 < d2 < d5


# ---------------------------------------------------------------------------
# Validation — every error branch
# ---------------------------------------------------------------------------


def test_rejects_walks_that_would_wrap() -> None:
    with pytest.raises(ValueError, match="would wrap"):
        coined_walk(START + 1)  # 17 steps from 16 wraps 32


@pytest.mark.parametrize("start,n,steps", [(0, 5, 1), (31, 5, 1), (1, 2, 2)])
def test_rejects_wrap_edge_cases(start: int, n: int, steps: int) -> None:
    with pytest.raises(ValueError, match="would wrap"):
        coined_walk(steps, n=n, start=start)


def test_rejects_negative_steps() -> None:
    with pytest.raises(ValueError, match="steps must be a non-negative int"):
        coined_walk(-1)


def test_rejects_unknown_coin_state() -> None:
    with pytest.raises(ValueError, match="coin_state must be one of"):
        coined_walk(3, coin_state="heads")  # type: ignore[arg-type]


def test_rejects_bad_n() -> None:
    with pytest.raises(ValueError, match="n must be an int"):
        coined_walk(1, n=0)
    with pytest.raises(ValueError, match="n must be an int"):
        coined_walk(1, n=9)
    with pytest.raises(ValueError, match="n must be an int"):
        coined_walk(1, n=-1)


def test_rejects_bad_start() -> None:
    with pytest.raises(ValueError, match="start must be int"):
        coined_walk(1, n=3, start=8)  # out of range 0..7
    with pytest.raises(ValueError, match="start must be int"):
        coined_walk(1, n=3, start=-1)


def test_rejects_float_steps() -> None:
    with pytest.raises(ValueError, match="steps must be a non-negative int"):
        coined_walk(1.5)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# exact_distribution golden values (regression lock)
# ---------------------------------------------------------------------------


def test_exact_distribution_golden_spreads() -> None:
    # Values from SPEC Appendix C (exact, not sampled)
    from quantum_walkers.classical import classical_distribution

    # classical σ = sqrt(t)
    for t, expected_c in [(1, 1.0), (5, 5**0.5), (10, 10**0.5), (15, 15**0.5)]:
        assert spread(classical_distribution(t)) == pytest.approx(expected_c, abs=1e-9)

    # quantum σ from live run (see README)
    assert spread(exact_distribution(1)) == pytest.approx(1.0, abs=1e-9)
    assert spread(exact_distribution(5)) == pytest.approx(2.828, abs=0.02)
    assert spread(exact_distribution(10)) == pytest.approx(5.47, abs=0.05)
    assert spread(exact_distribution(15)) == pytest.approx(8.14, abs=0.05)


# ---------------------------------------------------------------------------
# sampled_distribution
# ---------------------------------------------------------------------------


def test_simulator_samples_match_exact_distribution() -> None:
    sampled = sampled_distribution(10, shots=20_000, seed=1)
    total_variation = 0.5 * np.abs(sampled - exact_distribution(10)).sum()
    assert total_variation < 0.03
    # also sum to 1
    assert sampled.sum() == pytest.approx(1)


def test_sampled_deterministic_with_seed() -> None:
    a = sampled_distribution(5, shots=1000, seed=42)
    b = sampled_distribution(5, shots=1000, seed=42)
    assert np.allclose(a, b)


def test_sampled_rejects_bad_shots() -> None:
    with pytest.raises(ValueError, match="shots must be a positive int"):
        sampled_distribution(5, shots=0)
    with pytest.raises(ValueError, match="shots must be a positive int"):
        sampled_distribution(5, shots=-10)


# ---------------------------------------------------------------------------
# spread edge cases
# ---------------------------------------------------------------------------


def test_spread_delta_zero() -> None:
    probs = np.zeros(8)
    probs[3] = 1.0
    assert spread(probs) == pytest.approx(0)


def test_spread_rejects_bad_input() -> None:
    with pytest.raises(ValueError, match="must be 1-D"):
        spread(np.ones((2, 2)))
    with pytest.raises(ValueError, match="must be non-empty"):
        spread(np.array([]))


def test_spread_uniform() -> None:
    # 4 positions uniform: mean 1.5, variance 1.25, σ≈1.118
    probs = np.ones(4) / 4
    assert spread(probs) == pytest.approx(1.1180339, rel=1e-6)
