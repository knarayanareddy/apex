"""Tests for coin operators."""

import numpy as np
import pytest
from qiskit.quantum_info import Operator

from quantum_walkers.coins import coin_gate, fourier_coin, grover_coin, hadamard_coin


def test_hadamard_coin_is_unitary() -> None:
    h = hadamard_coin()
    assert h.is_unitary()
    assert h.data.shape == (2, 2)
    # H·H = I
    assert (h @ h).equiv(Operator.from_label("I"))
    # H is Hermitian: H = H†
    assert h.equiv(Operator(h.data.conj().T))


@pytest.mark.parametrize("dim", [2, 3, 4, 5])
def test_grover_coin_is_unitary(dim: int) -> None:
    g = grover_coin(dim)
    assert g.is_unitary()
    assert g.data.shape == (dim, dim)
    # Grover is real symmetric
    assert np.allclose(g.data.imag, 0)


def test_grover_coin_dim2_is_swap_like() -> None:
    # For dim=2, Grover = [[0,1],[1,0]]? Actually 2|s><s|-I with s=[1/√2,1/√2] → [[0,1],[1,0]]
    g = grover_coin(2)
    assert g.data == pytest.approx(np.array([[0, 1], [1, 0]], dtype=float))


def test_grover_rejects_bad_dim() -> None:
    with pytest.raises(ValueError, match="dim must be >=2"):
        grover_coin(1)


@pytest.mark.parametrize("dim", [2, 3, 4])
def test_fourier_coin_is_unitary(dim: int) -> None:
    f = fourier_coin(dim)
    assert f.is_unitary()
    assert f.data.shape == (dim, dim)
    # F @ F† == I already via is_unitary, but also check first row is uniform
    assert np.allclose(np.abs(f.data[0]), 1 / np.sqrt(dim))


def test_fourier_rejects_bad_dim() -> None:
    with pytest.raises(ValueError, match="dim must be >=2"):
        fourier_coin(1)


@pytest.mark.parametrize("name", ["hadamard", "grover", "fourier", "identity"])
def test_coin_gate_known_names(name: str) -> None:
    g = coin_gate(name)
    assert g is not None
    assert g.num_qubits >= 1


def test_coin_gate_hadamard_wrong_dim() -> None:
    with pytest.raises(ValueError, match="hadamard coin only supports dim=2"):
        coin_gate("hadamard", dim=4)


def test_coin_gate_unknown() -> None:
    with pytest.raises(ValueError, match="Unknown coin"):
        coin_gate("wacky")  # type: ignore[arg-type]
