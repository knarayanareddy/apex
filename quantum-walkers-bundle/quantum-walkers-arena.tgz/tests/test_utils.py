import numpy as np
import pytest

from quantum_walkers.utils import parity_mask, validate_probs


def test_validate_probs_ok():
    validate_probs(np.array([0.5, 0.5]))


def test_validate_probs_rejects_not_1d():
    with pytest.raises(ValueError, match="1-D"):
        validate_probs(np.ones((2, 2)))


def test_validate_probs_rejects_empty():
    with pytest.raises(ValueError, match="non-empty"):
        validate_probs(np.array([]))


def test_validate_probs_rejects_not_sum_one():
    with pytest.raises(ValueError, match="must sum to 1"):
        validate_probs(np.array([0.5, 0.4]))


def test_parity_mask():
    mask = parity_mask(n=3, start=4, steps=2)
    # n=3 -> 8 positions, start 4 even +2 even -> reachable even positions
    expected = np.array([p % 2 == 0 for p in range(8)])
    assert np.array_equal(mask, expected)
