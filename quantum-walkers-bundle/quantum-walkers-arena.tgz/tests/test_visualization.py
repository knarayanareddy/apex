"""Visualization smoke tests (AgG backend, tmp_path)."""

from pathlib import Path


def test_plot_comparison_creates_png(tmp_path: Path) -> None:
    from quantum_walkers.visualization import plot_comparison

    out = tmp_path / "comp.png"
    plot_comparison(steps=5, shots=200, path=str(out))
    assert out.exists()
    assert out.stat().st_size > 5_000  # non-empty PNG
    assert out.stat().st_size < 500_000


def test_plot_evolution_creates_png(tmp_path: Path) -> None:
    from quantum_walkers.visualization import plot_walk_evolution

    out = tmp_path / "evo.png"
    plot_walk_evolution(steps_list=[1, 5], path=str(out))
    assert out.exists()
    assert out.stat().st_size > 5_000


def test_examples_walk_comparison_script(tmp_path: Path) -> None:
    # Run the example script equivalent (not via subprocess, but via API)
    from quantum_walkers.visualization import plot_comparison

    out = tmp_path / "example.png"
    plot_comparison(steps=15, path=str(out))
    assert out.exists()


def test_walk_module_delegates_plot(tmp_path: Path) -> None:
    from quantum_walkers.walk import plot_comparison

    out = tmp_path / "delegated.png"
    plot_comparison(steps=3, shots=100, path=str(out))
    assert out.exists()
