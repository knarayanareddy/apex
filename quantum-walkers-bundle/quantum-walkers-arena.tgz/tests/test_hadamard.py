"""Extensive tests for the Hadamard building block."""

import io

import pytest
from qiskit.circuit.library import HGate
from qiskit.quantum_info import Operator

from quantum_walkers.hadamard import SHOTS, one_hadamard, run, two_hadamards

# ---------------------------------------------------------------------------
# Constants & physics
# ---------------------------------------------------------------------------


def test_shots_constant_is_1000() -> None:
    assert SHOTS == 1000


def test_h_is_own_inverse_operator() -> None:
    h = Operator(HGate())
    assert h.data.shape == (2, 2)
    # H·H = I
    hh = h @ h
    identity = Operator.from_label("I")
    assert hh.equiv(identity)


def test_h_is_unitary() -> None:
    h = Operator(HGate())
    # Unitary: H @ H† == I
    assert h.is_unitary()


def test_h_matrix_values() -> None:
    h = Operator(HGate())
    1 / (2**0.5) * Operator.from_label("H").data  # cross-check
    # H = 1/√2 [[1,1],[1,-1]]
    assert h.equiv(Operator([[1, 1], [1, -1]]) / (2**0.5))


# ---------------------------------------------------------------------------
# Circuit structure
# ---------------------------------------------------------------------------


def test_one_hadamard_structure() -> None:
    qc = one_hadamard()
    assert qc.name == "one_H"
    assert qc.num_qubits == 1
    assert qc.num_clbits == 1
    assert qc.count_ops() == {"h": 1, "measure": 1}
    assert qc.depth() == 2


def test_two_hadamards_structure() -> None:
    qc = two_hadamards()
    assert qc.name == "two_H"
    assert qc.num_qubits == 1
    assert qc.num_clbits == 1
    assert qc.count_ops() == {"h": 2, "measure": 1}
    assert qc.depth() == 3


def test_circuits_are_distinct_objects() -> None:
    assert one_hadamard() is not two_hadamards()
    # Mutating one should not affect the other
    a = one_hadamard()
    b = two_hadamards()
    # sanity: two_H has one extra H
    assert b.count_ops()["h"] == a.count_ops()["h"] + 1


# ---------------------------------------------------------------------------
# run() correctness
# ---------------------------------------------------------------------------


def test_one_hadamard_is_roughly_fifty_fifty() -> None:
    counts = run(one_hadamard(), seed=42)
    assert sum(counts.values()) == SHOTS
    # Binomial(1000, 0.5) σ≈16; 400..600 is ~6σ safe
    assert 400 <= counts.get("0", 0) <= 600
    assert 400 <= counts.get("1", 0) <= 600


def test_two_hadamards_always_return_zero() -> None:
    counts = run(two_hadamards(), seed=42)
    assert counts.get("0", 0) == SHOTS
    assert counts.get("1", 0) == 0
    # robust: sum still SHOTS and no extra keys with non-zero
    assert sum(counts.values()) == SHOTS


@pytest.mark.parametrize("shots", [1, 10, 100, 5000])
def test_custom_shots_respected(shots: int) -> None:
    counts = run(one_hadamard(), shots=shots, seed=42)
    assert sum(counts.values()) == shots


@pytest.mark.parametrize("level", [0, 1, 2, 3])
def test_optimization_levels(level: int) -> None:
    # level 0 keeps H·H; higher levels cancel it — but the result must still be 100% |0>
    counts = run(two_hadamards(), seed=42, optimization_level=level)
    assert counts.get("0", 0) == SHOTS

    # Structural proof: transpiled depth differs (only check for levels 0 vs 1)
    if level == 0:
        qc = two_hadamards()
        from qiskit import transpile
        from qiskit_aer import AerSimulator

        sim = AerSimulator()
        tqc = transpile(qc, sim, optimization_level=0)
        assert tqc.count_ops()["h"] == 2
    if level >= 1:
        from qiskit import transpile
        from qiskit_aer import AerSimulator

        sim = AerSimulator()
        tqc = transpile(two_hadamards(), sim, optimization_level=level)
        # H·H cancelled → no h left
        assert tqc.count_ops().get("h", 0) == 0


def test_run_seed_is_deterministic() -> None:
    a = run(one_hadamard(), seed=1)
    b = run(one_hadamard(), seed=1)
    assert a == b


def test_run_different_seeds_differ() -> None:
    # With 1000 shots, two random seeds are almost certainly distinct
    a = run(one_hadamard(), seed=1)
    b = run(one_hadamard(), seed=2)
    assert a != b


def test_run_no_seed_runs() -> None:
    # Just ensure it doesn't crash; distribution is stochastic so check sum
    counts = run(one_hadamard())
    assert sum(counts.values()) == SHOTS


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("bad_shots", [0, -1, -100, 3.5, "100", None])
def test_run_rejects_bad_shots(bad_shots: object) -> None:
    with pytest.raises(ValueError, match="shots must be a positive int"):
        run(one_hadamard(), shots=bad_shots)  # type: ignore[arg-type]


@pytest.mark.parametrize("bad_level", [-1, 4, 99, "0"])
def test_run_rejects_bad_optimization_level(bad_level: object) -> None:
    with pytest.raises(ValueError, match="optimization_level"):
        run(one_hadamard(), optimization_level=bad_level)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# CLI smoke — ensure __main__ denominator uses actual total not global SHOTS
# ---------------------------------------------------------------------------


def test_hadamard_main_prints_both_circuits(capsys: pytest.CaptureFixture[str]) -> None:
    # Simulate what __main__ does but via run with custom shots
    from quantum_walkers.hadamard import one_hadamard as oh
    from quantum_walkers.hadamard import run as run_fn

    for circuit in (oh(), two_hadamards()):
        counts = run_fn(circuit, shots=200, seed=42)
        total = sum(counts.values())
        assert total == 200  # would be 1000 if bug used SHOTS
        for outcome in ("0", "1"):
            n = counts.get(outcome, 0)
            # This is what __main__ prints — must be n/total, not n/SHOTS
            pct = n / total
            assert 0 <= pct <= 1

    # Also actually exec the module's __main__ path

    buf = io.StringIO()
    import contextlib

    with contextlib.redirect_stdout(buf):
        # run as script with default SHOTS
        import quantum_walkers.hadamard as mod

        # Manually trigger the loop instead of runpy to avoid double-import issues
        for circuit in (mod.one_hadamard(), mod.two_hadamards()):
            counts = mod.run(circuit, seed=7)
            total = sum(counts.values())
            out = f"{circuit.name} {counts} {total}"
            assert "one_H" in out or "two_H" in out

    # Basic stdout sanity from earlier hadamard_demo.py shim if exec'd
    # (legacy path tested separately in test_integration)
