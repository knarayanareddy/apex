"""Noise model helpers."""

import pytest

from quantum_walkers.noise import depolarizing_noise_model, readout_error_model


def test_depolarizing_noise_default() -> None:
    model = depolarizing_noise_model()
    assert model is not None


def test_depolarizing_custom() -> None:
    model = depolarizing_noise_model(p1=0.005, p2=0.02)
    assert model is not None


def test_depolarizing_zero_no_error() -> None:
    model = depolarizing_noise_model(p1=0, p2=0)
    # Should be empty/noise-free
    assert model is not None


def test_depolarizing_rejects_bad() -> None:
    with pytest.raises(ValueError, match="p1 and p2 must be in"):
        depolarizing_noise_model(p1=2)
    with pytest.raises(ValueError, match="p1 and p2 must be in"):
        depolarizing_noise_model(p2=-0.1)


def test_readout_error_default() -> None:
    model = readout_error_model()
    assert model is not None


def test_readout_custom() -> None:
    model = readout_error_model(p0g1=0.01, p1g0=0.03)
    assert model is not None


def test_readout_rejects_bad() -> None:
    with pytest.raises(ValueError, match="readout probabilities must be in"):
        readout_error_model(p0g1=1.5)


def test_noise_reduces_contrast() -> None:
    """With strong depolarizing noise, sampled distribution should be more uniform.

    We test that a very noisy simulator still runs and returns a distribution summing to 1.
    """
    from qiskit import transpile
    from qiskit_aer import AerSimulator

    from quantum_walkers.walk import coined_walk

    qc = coined_walk(5)
    # Noisy
    noise = depolarizing_noise_model(p1=0.05, p2=0.1)
    sim_noisy = AerSimulator(noise_model=noise, seed_simulator=42)
    noisy_counts = (
        sim_noisy.run(transpile(qc, sim_noisy), shots=2000).result().get_counts()
    )
    # Just check it runs and is still a valid distribution
    assert sum(noisy_counts.values()) == 2000
    assert len(noisy_counts) > 1
