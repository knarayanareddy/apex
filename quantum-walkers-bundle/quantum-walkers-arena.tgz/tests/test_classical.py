"""Tests for classical walk (pure NumPy, no Qiskit)."""

import numpy as np
import pytest

from quantum_walkers.classical import classical_distribution
from quantum_walkers.walk import spread


def test_classical_distribution_is_binomial() -> None:
    probs = classical_distribution(4)
    # START=16, 4 steps → reachable offsets -4,-2,0,2,4
    assert probs[16 - 4 : 16 + 5 : 2] == pytest.approx(
        [1 / 16, 4 / 16, 6 / 16, 4 / 16, 1 / 16]
    )
    assert spread(probs) == pytest.approx(2)


def test_classical_sums_to_one_and_parity() -> None:
    for t in [0, 1, 3, 5, 15]:
        probs = classical_distribution(t)
        assert probs.sum() == pytest.approx(1)
        # Only parity-compatible positions
        from quantum_walkers.walk import START

        unreachable = np.arange(len(probs)) % 2 != (START + t) % 2
        assert probs[unreachable].sum() == pytest.approx(0)


def test_classical_spread_is_sqrt_steps() -> None:
    for t in [1, 4, 9, 15]:
        probs = classical_distribution(t)
        assert spread(probs) == pytest.approx(t**0.5, rel=1e-12)


def test_classical_zero_steps() -> None:
    from quantum_walkers.walk import START

    probs = classical_distribution(0)
    assert probs[START] == pytest.approx(1)
    assert probs.sum() == pytest.approx(1)


def test_classical_no_qiskit_import() -> None:
    # classical_distribution must not import qiskit as side-effect
    # (we already imported quantum_walkers.walk earlier, so check fresh subprocess would be ideal,
    #  but at least ensure the function works without qiskit already in sys.modules causing it to load)
    # Here we just assert it returns correct value and doesn't require Aer
    probs = classical_distribution(2)
    assert probs[14] == pytest.approx(0.25)
    assert probs[16] == pytest.approx(0.5)
    assert probs[18] == pytest.approx(0.25)


def test_classical_custom_n_start() -> None:
    probs = classical_distribution(2, n=3, start=4)
    # n=3 → 8 positions, start 4, 2 steps: can go to 2,4,6
    assert len(probs) == 8
    assert probs[2] == pytest.approx(0.25)
    assert probs[4] == pytest.approx(0.5)
    assert probs[6] == pytest.approx(0.25)


@pytest.mark.parametrize("bad", [(-1, 5, 16), (1, 0, 0), (1, 5, 32), (1, 5, -1)])
def test_classical_rejects_bad_inputs(bad: tuple[int, int, int]) -> None:
    steps, n, start = bad
    with pytest.raises(ValueError):
        classical_distribution(steps, n=n, start=start)


def test_classical_wrap_guard() -> None:
    with pytest.raises(ValueError, match="would wrap"):
        classical_distribution(17, n=5, start=16)

    # Also 3 steps from 1 with n=3 (0..7) would wrap on left (1-3=-2)
    with pytest.raises(ValueError, match="would wrap"):
        classical_distribution(2, n=2, start=0)
