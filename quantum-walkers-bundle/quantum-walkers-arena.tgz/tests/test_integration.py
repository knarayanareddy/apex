"""Integration / regression / backwards-compat tests."""

import subprocess
import sys

import numpy as np
import pytest

from quantum_walkers.walk import exact_distribution, spread


def test_backwards_compat_shims() -> None:
    # Old flat imports must keep working
    import coined_walk as cw
    import hadamard_demo as hd

    assert hasattr(hd, "one_hadamard")
    assert hasattr(hd, "two_hadamards")
    assert hasattr(hd, "run")
    assert hasattr(cw, "coined_walk")
    assert hasattr(cw, "exact_distribution")
    assert hasattr(cw, "classical_distribution")

    # Functional parity: old vs new package give same result
    from quantum_walkers.hadamard import one_hadamard as new_oh
    from quantum_walkers.walk import coined_walk as new_cw

    assert hd.one_hadamard().count_ops() == new_oh().count_ops()
    assert cw.coined_walk(2).count_ops() == new_cw(2).count_ops()


def test_package_imports() -> None:
    import quantum_walkers

    assert quantum_walkers.__version__ == "0.1.0"
    assert hasattr(quantum_walkers, "coined_walk")
    assert hasattr(quantum_walkers, "classical_distribution")


def test_demo_scripts_run(tmp_path) -> None:
    # Legacy shims as scripts
    for script in ["hadamard_demo.py", "coined_walk.py"]:
        result = subprocess.run(
            [sys.executable, script],
            capture_output=True,
            text=True,
            cwd="/tmp/qw",
            timeout=30,
        )
        assert result.returncode == 0, f"{script} failed: {result.stderr}"
        assert len(result.stdout) > 0


def test_example_script_runs(tmp_path) -> None:
    result = subprocess.run(
        [sys.executable, "examples/walk_comparison.py"],
        capture_output=True,
        text=True,
        cwd="/tmp/qw",
        timeout=30,
    )
    assert result.returncode == 0, result.stderr
    # check it wrote to example_output
    from pathlib import Path

    p = Path("/tmp/qw/example_output/walk_comparison.png")
    assert p.exists()
    assert p.stat().st_size > 5_000


def test_golden_exact_distribution_snapshot() -> None:
    """Lock exact_distribution for t=5 to catch silent regressions."""
    probs = exact_distribution(5)
    # Hand-captured golden values for key positions (START=16, 5 steps)
    # Computed once with qiskit 2.6.1, aer 0.18.2
    # Only central peaks are non-trivial; we snapshot spread and a few probs
    assert spread(probs) == pytest.approx(2.82842712, abs=1e-6)
    # Symmetry
    for d in range(6):
        assert probs[16 + d] == pytest.approx(probs[16 - d], abs=1e-12)
    # Unreachable parity zeros
    assert probs[16] == pytest.approx(
        0, abs=1e-12
    )  # 5 steps from 16 → parity 1, so 16 even is unreachable
    # Reachable extremes: positions 11 and 21 should each have ~0.03125 (=1/32)
    assert probs[11] == pytest.approx(0.03125, abs=1e-9)
    assert probs[21] == pytest.approx(0.03125, abs=1e-9)


def test_full_walk_matrix_is_unitary_via_statevector_norm() -> None:
    from qiskit.quantum_info import Statevector

    from quantum_walkers.walk import coined_walk

    for steps in [0, 1, 3]:
        qc = coined_walk(steps, measure=False)
        sv = Statevector(qc)
        assert np.isclose(np.linalg.norm(sv.data), 1, atol=1e-9)


def test_no_secrets_in_repo() -> None:
    # Simple check that no committed file contains a literal token
    import pathlib

    for p in pathlib.Path("/tmp/qw").rglob("*.py"):
        if ".venv" in str(p) or "__pycache__" in str(p) or ".git" in str(p):
            continue
        text = p.read_text()
        assert (
            "QISKIT_IBM_TOKEN" not in text or "getenv" in text or "os.getenv" in text
        ), f"potential leak in {p}"
        # no raw token pattern
        assert "apikey" not in text.lower() or "example" in text.lower()
