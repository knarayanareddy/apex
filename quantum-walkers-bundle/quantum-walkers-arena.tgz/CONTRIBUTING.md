# Contributing

## Setup

```bash
git clone https://github.com/TonyBarratt100/quantum-walkers.git
cd quantum-walkers
python3 -m venv .venv && source .venv/bin/activate
pip install -e .[dev]
pre-commit install
```

## Workflow

1. Create a branch: `git checkout -b feat/your-idea`
2. Write code + tests (aim for ≥85% coverage).
3. Run checks locally:

```bash
pytest --cov
ruff check . && ruff format --check .
black --check .
mypy --strict src/quantum_walkers
pre-commit run --all-files
```

4. Open a PR — both `tests` and `lint` workflows must be green.

## Adding a new coin

Implement in `src/quantum_walkers/coins.py`, add a test in `tests/test_coins.py`, and expose it via `quantum_walkers.coins.coin_gate`.

## Commit messages

Use [Conventional Commits](https://www.conventionalcommits.org/): `feat:`, `fix:`, `docs:`, `test:`, `chore:`.
