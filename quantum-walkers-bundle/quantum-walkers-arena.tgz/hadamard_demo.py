"""Compare one Hadamard gate with two, measured over many shots on AerSimulator.

Thin shim — canonical implementation lives in src/quantum_walkers/hadamard.py.
Kept for backwards compatibility with `import hadamard_demo`.
"""

from quantum_walkers.hadamard import SHOTS, one_hadamard, run, two_hadamards

__all__ = ["SHOTS", "one_hadamard", "run", "two_hadamards"]

if __name__ == "__main__":
    for circuit in (one_hadamard(), two_hadamards()):
        counts = run(circuit)
        total = sum(counts.values())
        print(f"\n=== {circuit.name} ===")
        print(circuit.draw(output="text"))
        for outcome in ("0", "1"):
            n = counts.get(outcome, 0)
            print(f"  |{outcome}>: {n:4d}  ({n / total:.1%})")
