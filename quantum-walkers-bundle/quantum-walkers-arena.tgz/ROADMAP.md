# Roadmap

## v0.2 — Walk zoo

- [ ] Walk on a cycle (periodic boundary, no wrap guard)
- [ ] 2-D walk on a grid (4-dim coin, Grover + Hadamard variants)
- [ ] Parameterized coin family `R_y(theta)` and bias sweep notebook

## v0.3 — Noise & hardware

- [ ] Depolarizing + amplitude damping comparison sweeps
- [ ] IBM hardware run with error mitigation (`resilience_level=1`) and cost estimate

## v0.4 — Algorithms

- [ ] Szegedy walk / quantum search on a marked node
- [ ] Continuous-time walk via Trotterization

## v1.0

- [ ] Published Fall Fest workshop kit with slides + attendee exercises

Contributions welcome — open an issue to claim an item.
