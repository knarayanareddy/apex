"""Run the walk on IBM Quantum hardware (requires QISKIT_IBM_TOKEN).

Usage:
    QISKIT_IBM_TOKEN=... python examples/hardware_run.py --steps 5

Safe to run without a token — script will exit with instructions.
"""

import argparse
import os
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description="Run walk on IBM hardware")
    parser.add_argument("--steps", type=int, default=5, help="Walk steps")
    parser.add_argument("--backend", type=str, default=None, help="Backend name")
    args = parser.parse_args()

    token = os.getenv("QISKIT_IBM_TOKEN")
    if not token:
        print("No QISKIT_IBM_TOKEN set.")
        print("  1. Get a token at https://quantum.ibm.com/")
        print("  2. export QISKIT_IBM_TOKEN=your_token")
        print("  3. Rerun this script")
        print("\nSimulating locally instead:")
        from quantum_walkers.classical import classical_distribution
        from quantum_walkers.walk import exact_distribution, spread

        print(f"  classical σ = {spread(classical_distribution(args.steps)):.2f}")
        print(f"  quantum σ   = {spread(exact_distribution(args.steps)):.2f}")
        sys.exit(0)

    # Lazy import so CI without qiskit-ibm-runtime still passes
    try:
        from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2  # type: ignore[import-untyped]
    except ImportError:
        print("qiskit-ibm-runtime not installed. pip install qiskit-ibm-runtime")
        sys.exit(1)

    from quantum_walkers.walk import coined_walk

    service = QiskitRuntimeService(channel="ibm_quantum", token=token)
    backend = (
        service.backend(args.backend)
        if args.backend
        else service.least_busy(simulator=False, operational=True)
    )
    print(f"Using backend: {backend.name}")
    qc = coined_walk(args.steps)
    sampler = SamplerV2(mode=backend)
    job = sampler.run([qc], shots=1024)
    result = job.result()
    print(result[0].data.x.get_counts())  # type: ignore[attr-defined]


if __name__ == "__main__":
    main()
