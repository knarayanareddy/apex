"""Regenerate the walk comparison figure via the package API."""

from pathlib import Path

from quantum_walkers.classical import classical_distribution
from quantum_walkers.visualization import plot_comparison
from quantum_walkers.walk import exact_distribution, spread

if __name__ == "__main__":
    print(f"{'steps':>5}  {'classical σ':>11}  {'quantum σ':>9}")
    for t in (1, 5, 10, 15):
        print(
            f"{t:5d}  {spread(classical_distribution(t)):11.2f}  {spread(exact_distribution(t)):9.2f}"
        )
    out = Path("example_output/walk_comparison.png")
    out.parent.mkdir(exist_ok=True)
    plot_comparison(path=str(out))
    print(f"\nSaved {out}")
