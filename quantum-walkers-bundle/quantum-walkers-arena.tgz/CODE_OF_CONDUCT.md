# Code of Conduct

We follow the [Contributor Covenant](https://www.contributor-covenant.org/version/2/1/code_of_conduct/). Be kind, be collaborative, and assume good intent. Harassment or discrimination of any kind is not tolerated. Report concerns to the maintainers via GitHub issues or email.
