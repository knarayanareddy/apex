import numpy as np
import pytest
from qiskit.quantum_info import Operator

from coined_walk import (
    POSITION_QUBITS,
    START,
    classical_distribution,
    coined_walk,
    exact_distribution,
    increment,
    sampled_distribution,
    spread,
)


def test_increment_adds_one_mod_2n():
    n = 3
    op = Operator(increment(n)).data
    for x in range(2**n):
        assert op[(x + 1) % 2**n, x] == pytest.approx(1)


def test_zero_steps_stays_at_start():
    probs = exact_distribution(0)
    assert probs[START] == pytest.approx(1)


def test_one_step_is_fifty_fifty_left_right():
    probs = exact_distribution(1)
    assert probs[START - 1] == pytest.approx(0.5)
    assert probs[START + 1] == pytest.approx(0.5)


@pytest.mark.parametrize("steps", [3, 8, 15])
def test_probabilities_sum_to_one_and_respect_parity(steps):
    probs = exact_distribution(steps)
    assert probs.sum() == pytest.approx(1)
    unreachable = np.arange(len(probs)) % 2 != (START + steps) % 2
    assert probs[unreachable].sum() == pytest.approx(0, abs=1e-12)


def test_symmetric_coin_gives_symmetric_distribution():
    probs = exact_distribution(10)
    d = np.arange(11)
    assert np.allclose(probs[START + d], probs[START - d])


def test_basis_coin_states_drift_in_opposite_directions():
    x = np.arange(2**POSITION_QUBITS)
    left = exact_distribution(10, coin_state="zero") @ x - START
    right = exact_distribution(10, coin_state="one") @ x - START
    assert left < -1
    assert right == pytest.approx(-left)


def test_quantum_walk_spreads_faster_than_classical():
    # Quantum spread grows ~0.54 * steps; classical grows sqrt(steps)
    steps = 15
    assert spread(exact_distribution(steps)) > 2 * spread(classical_distribution(steps))


def test_classical_distribution_is_binomial():
    probs = classical_distribution(4)
    assert probs[START - 4 : START + 5 : 2] == pytest.approx(
        [1 / 16, 4 / 16, 6 / 16, 4 / 16, 1 / 16]
    )
    assert spread(probs) == pytest.approx(2)


def test_simulator_samples_match_exact_distribution():
    sampled = sampled_distribution(10, shots=20_000, seed=1)
    total_variation = 0.5 * np.abs(sampled - exact_distribution(10)).sum()
    assert total_variation < 0.03


def test_rejects_walks_that_would_wrap():
    with pytest.raises(ValueError):
        coined_walk(START + 1)


def test_rejects_unknown_coin_state():
    with pytest.raises(ValueError):
        coined_walk(3, coin_state="heads")
