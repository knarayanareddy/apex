from hadamard_demo import SHOTS, one_hadamard, run, two_hadamards


def test_one_hadamard_is_roughly_fifty_fifty():
    counts = run(one_hadamard(), seed=42)
    assert sum(counts.values()) == SHOTS
    # Binomial(1000, 0.5) has std dev ~16; 400..600 is a very safe band
    assert 400 <= counts.get("0", 0) <= 600


def test_two_hadamards_always_return_zero():
    counts = run(two_hadamards(), seed=42)
    assert counts.get("0", 0) == SHOTS
    assert counts.get("1", 0) == 0
