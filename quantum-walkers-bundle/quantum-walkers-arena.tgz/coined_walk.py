"""Discrete-time coined quantum walk on a line — shim for backwards compatibility.

Canonical implementation: src/quantum_walkers/walk.py, classical.py, visualization.py
"""

from quantum_walkers.classical import classical_distribution
from quantum_walkers.walk import (
    COIN_STATES,
    POSITION_QUBITS,
    START,
    coined_walk,
    exact_distribution,
    increment,
    plot_comparison,
    sampled_distribution,
    spread,
)
from quantum_walkers.walk import (
    classical_distribution as _cd_compat,  # noqa: F401 keep alias for old tests
)

# Re-export classical_distribution from its new home too
__all__ = [
    "COIN_STATES",
    "POSITION_QUBITS",
    "START",
    "classical_distribution",
    "coined_walk",
    "exact_distribution",
    "increment",
    "plot_comparison",
    "sampled_distribution",
    "spread",
]

if __name__ == "__main__":
    print(f"{'steps':>5}  {'classical σ':>11}  {'quantum σ':>9}")
    for t in (1, 5, 10, 15):
        print(
            f"{t:5d}  {spread(classical_distribution(t)):11.2f}  {spread(exact_distribution(t)):9.2f}"
        )
    plot_comparison()
    print("\nSaved walk_comparison.png")
