## What
## Why (link issue)
## Checks
- [ ] Tests pass
- [ ] `ruff` / `black` / `mypy` green
- [ ] Docs updated
